package playlist;

import java.util.ArrayList;
import gestionnaireFichiers.FichierMp3;

/**
 * Représente une playlist audio, c’est-à-dire une liste ordonnée de morceaux
 * audio ({@link FichierMp3}) associée à un nom.
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe modélise une playlist de manière simple et indépendante
 * de toute interface utilisateur (CLI ou GUI).
 * </p>
 *
 * <p>
 * Elle permet notamment :
 * </p>
 * <ul>
 *   <li>de créer une playlist vide avec un nom,</li>
 *   <li>d’ajouter ou de supprimer des morceaux,</li>
 *   <li>d’accéder à la liste des morceaux,</li>
 *   <li>d’obtenir des informations globales (taille, affichage texte).</li>
 * </ul>
 *
 * <h2>Architecture</h2>
 * <p>
 * Cette classe appartient à la couche métier du projet :
 * </p>
 * <ul>
 *   <li>elle ne gère ni l’affichage (GUI/CLI),</li>
 *   <li>ni l’accès aux fichiers directement,</li>
 *   <li>
 *	     elle est manipulée par
 *   	 {@link playlist.GestionPlaylist},
 *   	 {@link ihm.GUI}
 *   	 et {@link ihm.CLI}.
 *   </li>

 * </ul>
 *
 * <p>
 * Les morceaux sont stockés dans une {@link ArrayList}, ce qui permet :
 * </p>
 * <ul>
 *   <li>un accès indexé rapide,</li>
 *   <li>un ordre de lecture stable,</li>
 *   <li>une modification simple (ajout / suppression).</li>
 * </ul>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class Playlist {

    // -------------------------------------------------------------------------
    // ATTRIBUTS
    // -------------------------------------------------------------------------

    /**
     * Nom de la playlist.
     *
     * <p>
     * Exemple : {@code "Playlist par défaut"}, {@code "Ma sélection"}.
     * </p>
     */
    private String nom;

    /**
     * Liste des morceaux composant la playlist.
     *
     * <p>
     * Chaque élément de la liste est un {@link FichierMp3}.
     * L’ordre de la liste correspond à l’ordre de lecture.
     * </p>
     */
    private ArrayList<FichierMp3> morceaux;

    // -------------------------------------------------------------------------
    // CONSTRUCTEUR
    // -------------------------------------------------------------------------

    /**
     * Construit une playlist vide avec le nom fourni.
     *
     * @param nom nom de la playlist
     */
    public Playlist(String nom) {
        this.nom = nom;
        this.morceaux = new ArrayList<>();
    }

    // -------------------------------------------------------------------------
    // ACCESSEURS
    // -------------------------------------------------------------------------

    /**
     * Retourne le nom de la playlist.
     *
     * @return nom de la playlist
     */
    public String getNom() {
        return nom;
    }

    /**
     * Modifie le nom de la playlist.
     *
     * @param nom nouveau nom de la playlist
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Retourne la liste des morceaux de la playlist.
     *
     * <p>
     * ⚠️ La liste retournée est directement modifiable.
     * Toute modification impactera la playlist.
     * </p>
     *
     * @return liste des {@link FichierMp3} de la playlist
     */
    public ArrayList<FichierMp3> getMorceaux() {
        return morceaux;
    }

    // -------------------------------------------------------------------------
    // GESTION DES MORCEAUX
    // -------------------------------------------------------------------------

    /**
     * Ajoute un morceau à la playlist.
     *
     * <p>
     * Si le paramètre est {@code null}, l’ajout est ignoré.
     * </p>
     *
     * @param musique morceau à ajouter
     */
    public void ajouterMusique(FichierMp3 musique) {
        if (musique != null) {
            morceaux.add(musique);
        }
    }

    /**
     * Supprime un morceau de la playlist.
     *
     * @param musique morceau à supprimer
     * @return {@code true} si le morceau était présent et supprimé,
     *         {@code false} sinon
     */
    public boolean supprimerMusique(FichierMp3 musique) {
        if (musique == null) {
            return false;
        }
        return morceaux.remove(musique);
    }

    /**
     * Retourne le nombre total de morceaux dans la playlist.
     *
     * @return nombre de morceaux
     */
    public int getTaille() {
        return morceaux.size();
    }

    // -------------------------------------------------------------------------
    // AFFICHAGE
    // -------------------------------------------------------------------------

    /**
     * Retourne une représentation textuelle de la playlist.
     *
     * <p>
     * Le format inclut :
     * </p>
     * <ul>
     *   <li>le nom de la playlist,</li>
     *   <li>le nombre de morceaux,</li>
     *   <li>la liste numérotée des fichiers MP3.</li>
     * </ul>
     *
     * <p>
     * Cette méthode est principalement utilisée pour l’affichage
     * dans l’interface graphique (GUI) ou pour du debug.
     * </p>
     *
     * @return représentation textuelle de la playlist
     */
    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        sb.append("Playlist : ").append(nom).append("\n");
        sb.append("Nombre de morceaux : ").append(morceaux.size()).append("\n");

        for (int i = 0; i < morceaux.size(); i++) {
            FichierMp3 f = morceaux.get(i);
            sb.append(String.format("%02d - %s%n", i + 1, f.getNomFichier()));
        }

        return sb.toString();
    }
}
