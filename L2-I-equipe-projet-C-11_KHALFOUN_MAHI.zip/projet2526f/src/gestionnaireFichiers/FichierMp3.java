package gestionnaireFichiers;

import java.io.File;
import metadonnees.Metadonnees;

/**
 * Représente un fichier audio MP3 présent sur le système de fichiers.
 *
 * <p>
 * Cette classe encapsule un {@link File} correspondant à un fichier MP3
 * et permet l'accès à ses métadonnées via un chargement différé
 * (lazy loading).
 * </p>
 *
 * <p>
 * Les métadonnées ne sont pas lues lors de l'instanciation afin
 * d'éviter un coût inutile en ressources. Elles sont chargées
 * uniquement lors du premier appel à {@link #getMetadonnees()}.
 * </p>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class FichierMp3 {

    /**
     * Chemin du fichier MP3 sur le système de fichiers.
     */
    private File cheminFichier;

    /**
     * Nom du fichier MP3 (sans le chemin).
     */
    private String nomFichier;

    /**
     * Métadonnées associées au fichier MP3.
     * Initialement null, elles sont chargées à la demande.
     */
    private Metadonnees metadonnees;

    // ------------------------------------------------------------------
    // CONSTRUCTEUR
    // ------------------------------------------------------------------

    /**
     * Construit un objet {@code FichierMp3} à partir d'un fichier existant.
     *
     * <p>
     * Les métadonnées ne sont pas chargées lors de la construction.
     * </p>
     *
     * @param cheminFichier fichier MP3 à représenter
     * @throws IllegalArgumentException si le fichier est null
     */
    public FichierMp3(File cheminFichier) {
        if (cheminFichier == null) {
            throw new IllegalArgumentException("Le fichier MP3 ne peut pas être null.");
        }
        this.cheminFichier = cheminFichier;
        this.nomFichier = cheminFichier.getName();
        this.metadonnees = null;
    }

    // ------------------------------------------------------------------
    // GETTERS
    // ------------------------------------------------------------------

    /**
     * Retourne le chemin complet du fichier MP3.
     *
     * @return objet {@link File} représentant le fichier MP3
     */
    public File getCheminFichier() {
        return cheminFichier;
    }

    /**
     * Retourne le nom du fichier MP3.
     *
     * @return nom du fichier
     */
    public String getNomFichier() {
        return nomFichier;
    }

    // ------------------------------------------------------------------
    // SETTERS
    // ------------------------------------------------------------------

    /**
     * Modifie le nom du fichier MP3.
     *
     * @param nomFichier nouveau nom du fichier
     */
    public void setNomFichier(String nomFichier) {
        this.nomFichier = nomFichier;
    }

    // ------------------------------------------------------------------
    // MÉTADONNÉES
    // ------------------------------------------------------------------

    /**
     * Retourne les métadonnées du fichier MP3.
     *
     * <p>
     * Les métadonnées sont chargées une seule fois lors du premier appel
     * à cette méthode (chargement différé).
     * </p>
     *
     * @return objet {@link Metadonnees} contenant les informations du fichier,
     *         ou {@code null} si la lecture échoue
     */
    public Metadonnees getMetadonnees() {
        if (metadonnees == null) {
            try {
                metadonnees = new Metadonnees(cheminFichier.getAbsolutePath());
            } catch (Exception e) {
                e.printStackTrace();
                metadonnees = null;
            }
        }
        return metadonnees;
    }
}
