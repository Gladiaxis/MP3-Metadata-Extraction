package ihm;

import gestionnaireFichiers.FichierMp3;
import gestionnaireFichiers.Repertoires;
import metadonnees.Metadonnees;
import playlist.FormatPlaylist;
import playlist.GestionPlaylist;
import playlist.Playlist;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * Fenêtre principale de l'application MP3 en mode graphique (Swing).
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe fournit une interface utilisateur permettant :
 * </p>
 * <ul>
 *   <li>de sélectionner un dossier et d'en lister les fichiers MP3 (bibliothèque),</li>
 *   <li>d'afficher les métadonnées d'un fichier MP3 (titre, artiste, album, année, durée),</li>
 *   <li>d'afficher une pochette (cover) lorsque disponible,</li>
 *   <li>de construire et manipuler une playlist (ajout / retrait de morceaux),</li>
 *   <li>d'exporter la playlist dans différents formats ({@link FormatPlaylist}),</li>
 *   <li>d'importer une playlist au format M3U8 via {@link PlaylistIO}.</li>
 * </ul>
 *
 * <h2>Organisation interne</h2>
 * <p>
 * L'interface est composée de :
 * </p>
 * <ul>
 *   <li>une barre d'actions en haut (ouvrir MP3, explorer dossier, playlist par défaut, vider),</li>
 *   <li>un panneau central scindé (bibliothèque + métadonnées à gauche, playlist à droite),</li>
 *   <li>une barre en bas (export/import de playlist).</li>
 * </ul>
 *
 * <h2>Flux principal</h2>
 * <ol>
 *   <li>L'utilisateur explore un dossier → la bibliothèque est alimentée.</li>
 *   <li>L'utilisateur sélectionne un fichier → les métadonnées sont chargées et affichées.</li>
 *   <li>L'utilisateur ajoute/retire des fichiers → l'objet {@link Playlist} est mis à jour.</li>
 *   <li>L'utilisateur exporte ou importe une playlist.</li>
 * </ol>
 *
 * <p>
 * Cette classe étend {@link JFrame} et constitue la fenêtre principale.
 * </p>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class GUI extends JFrame {

    private static final long serialVersionUID = 1L;

    // ==================================================================
    // DONNÉES / ÉTAT
    // ==================================================================

    /**
     * Répertoire courant sélectionné par l'utilisateur.
     * <p>
     * Utilisé pour :
     * </p>
     * <ul>
     *   <li>positionner les {@link JFileChooser} au bon endroit,</li>
     *   <li>construire une playlist par défaut à partir du dossier en cours.</li>
     * </ul>
     */
    private File currentDirectory = null;

    /**
     * Modèle Swing contenant la "bibliothèque" (liste de fichiers MP3)
     * issue du dernier dossier exploré.
     */
    private final DefaultListModel<FichierMp3> libraryModel = new DefaultListModel<>();

    /**
     * Modèle Swing contenant la "playlist" (liste de fichiers MP3)
     * présents dans {@link #currentPlaylist}.
     */
    private final DefaultListModel<FichierMp3> playlistModel = new DefaultListModel<>();

    /**
     * Playlist actuellement manipulée dans l'interface (ajout/retrait, export).
     */
    private Playlist currentPlaylist = new Playlist("Playlist GUI");

    // ==================================================================
    // COMPOSANTS UI
    // ==================================================================

    /** Liste Swing affichant la bibliothèque des MP3 du dossier. */
    private final JList<FichierMp3> libraryList = new JList<>(libraryModel);

    /** Liste Swing affichant le contenu de la playlist courante. */
    private final JList<FichierMp3> playlistList = new JList<>(playlistModel);

    /** Libellés de métadonnées affichés dans le panneau "Métadonnées". */
    private final JLabel lblFile = new JLabel("Fichier : ");
    private final JLabel lblTitle = new JLabel("Titre : ");
    private final JLabel lblArtist = new JLabel("Artiste : ");
    private final JLabel lblAlbum = new JLabel("Album : ");
    private final JLabel lblYear = new JLabel("Année : ");
    private final JLabel lblDuration = new JLabel("Durée : ");
    private final JLabel lblCover = new JLabel("Cover : ");

    /**
     * Zone d'affichage de la pochette (cover).
     * <p>
     * Soit une image redimensionnée (thumbnail), soit un texte ("Aucune cover").
     * </p>
     */
    private final JLabel coverLabel = new JLabel();

    // ==================================================================
    // SERVICES
    // ==================================================================

    /**
     * Service de gestion des playlists (création par défaut, export, enregistrement).
     * <p>
     * Cette classe encapsule la logique de création et de sérialisation de playlist.
     * </p>
     */
    private final GestionPlaylist gestionPlaylist = new GestionPlaylist();

    /**
     * Utilitaire de lecture de playlist M3U8.
     * <p>
     * La classe {@link PlaylistIO} n'est pas fournie ici, mais elle est supposée
     * pouvoir charger une playlist à partir d'un fichier.
     * </p>
     */
    private final PlaylistIO playlistIO = new PlaylistIO();

    // ==================================================================
    // CONSTRUCTEUR
    // ==================================================================

    /**
     * Construit et initialise la fenêtre principale.
     *
     * <p>
     * Étapes réalisées :
     * </p>
     * <ol>
     *   <li>initialisation de la fenêtre Swing ({@link JFrame})</li>
     *   <li>construction des panneaux (haut / centre / bas)</li>
     *   <li>configuration des renderers de listes (affichage du nom fichier)</li>
     *   <li>installation des listeners (sélection bibliothèque → affichage métadonnées)</li>
     *   <li>synchronisation de la vue playlist avec l'objet {@link #currentPlaylist}</li>
     * </ol>
     */
    public GUI() {
        super("Projet MP3 - GUI (Swing)");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 650);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(buildTopBar(), BorderLayout.NORTH);
        add(buildMainSplit(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);

        setupRenderers();
        setupListeners();
        refreshPlaylistViewFromObject();
    }

    // ==================================================================
    // BUILDERS UI
    // ==================================================================

    /**
     * Construit la barre supérieure contenant les actions principales.
     *
     * <p>
     * Boutons :
     * </p>
     * <ul>
     *   <li>Ouvrir MP3 : sélection d'un fichier et affichage métadonnées</li>
     *   <li>Explorer dossier : exploration récursive et remplissage bibliothèque</li>
     *   <li>Playlist par défaut : création d'une playlist depuis le dossier courant</li>
     *   <li>Vider playlist : réinitialise {@link #currentPlaylist}</li>
     * </ul>
     *
     * @return composant Swing prêt à être ajouté à la fenêtre
     */
    private JComponent buildTopBar() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton btnOpenMp3 = new JButton("Ouvrir MP3...");
        JButton btnExploreDir = new JButton("Explorer dossier...");
        JButton btnDefaultPlaylist = new JButton("Playlist par défaut");
        JButton btnClearPlaylist = new JButton("Vider playlist");

        btnOpenMp3.addActionListener(e -> chooseAndShowMp3Metadata());
        btnExploreDir.addActionListener(e -> chooseAndExploreDirectory());
        btnDefaultPlaylist.addActionListener(e -> buildDefaultPlaylistFromCurrentDir());
        btnClearPlaylist.addActionListener(e -> clearPlaylist());

        panel.add(btnOpenMp3);
        panel.add(btnExploreDir);
        panel.add(btnDefaultPlaylist);
        panel.add(btnClearPlaylist);

        return panel;
    }

    /**
     * Construit la zone centrale scindée en deux :
     * <ul>
     *   <li>à gauche : bibliothèque + métadonnées</li>
     *   <li>à droite : playlist</li>
     * </ul>
     *
     * @return composant central (split pane)
     */
    private JComponent buildMainSplit() {
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.55);

        JPanel left = new JPanel(new BorderLayout(10, 10));
        left.setBorder(new EmptyBorder(10, 10, 10, 10));
        left.add(buildLibraryPanel(), BorderLayout.CENTER);
        left.add(buildMetadataPanel(), BorderLayout.SOUTH);

        JPanel right = new JPanel(new BorderLayout(10, 10));
        right.setBorder(new EmptyBorder(10, 10, 10, 10));
        right.add(buildPlaylistPanel(), BorderLayout.CENTER);

        split.setLeftComponent(left);
        split.setRightComponent(right);

        return split;
    }

    /**
     * Construit le panneau "Bibliothèque" (liste des MP3 détectés dans le dossier).
     *
     * <p>
     * Ce panneau inclut aussi les boutons d'ajout/retrait vers la playlist.
     * </p>
     *
     * @return panneau Swing de bibliothèque
     */
    private JComponent buildLibraryPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));

        JLabel title = new JLabel("Bibliothèque MP3");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 14f));
        panel.add(title, BorderLayout.NORTH);

        libraryList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        panel.add(new JScrollPane(libraryList), BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnAdd = new JButton("Ajouter → Playlist");
        JButton btnRemove = new JButton("Retirer ← Playlist");

        btnAdd.addActionListener(e -> addSelectedToPlaylist());
        btnRemove.addActionListener(e -> removeSelectedFromPlaylist());

        buttons.add(btnAdd);
        buttons.add(btnRemove);

        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    /**
     * Construit le panneau "Métadonnées".
     *
     * <p>
     * Affiche :
     * </p>
     * <ul>
     *   <li>les libellés (fichier, titre, artiste, album, année, durée)</li>
     *   <li>la pochette si disponible</li>
     *   <li>un bouton pour enregistrer les métadonnées affichées en TXT</li>
     * </ul>
     *
     * @return panneau Swing de métadonnées
     */
    private JComponent buildMetadataPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createTitledBorder("Métadonnées"));

        coverLabel.setPreferredSize(new Dimension(180, 180));
        coverLabel.setHorizontalAlignment(SwingConstants.CENTER);
        coverLabel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        coverLabel.setText("Aucune cover");

        panel.add(coverLabel, BorderLayout.WEST);

        JPanel text = new JPanel(new GridLayout(0, 1, 4, 4));
        text.add(lblFile);
        text.add(lblTitle);
        text.add(lblArtist);
        text.add(lblAlbum);
        text.add(lblYear);
        text.add(lblDuration);
        text.add(lblCover);

        panel.add(text, BorderLayout.CENTER);

        JButton btnSave = new JButton("Sauvegarder métadonnées (TXT)");
        btnSave.addActionListener(e -> saveDisplayedMetadataToTxt());
        panel.add(btnSave, BorderLayout.SOUTH);

        return panel;
    }

    /**
     * Construit le panneau "Playlist".
     *
     * @return panneau Swing contenant la liste de playlist
     */
    private JComponent buildPlaylistPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        JLabel title = new JLabel("Playlist");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 14f));

        playlistList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        panel.add(title, BorderLayout.NORTH);
        panel.add(new JScrollPane(playlistList), BorderLayout.CENTER);

        return panel;
    }

    /**
     * Construit la barre inférieure contenant l'import/export des playlists.
     *
     * <p>
     * - Export : via {@link GestionPlaylist#enregistrerDansFichier(Playlist, FormatPlaylist, String)}<br>
     * - Import : via {@link PlaylistIO#loadM3U8(File)}
     * </p>
     *
     * @return barre inférieure Swing
     */
    private JComponent buildBottomBar() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton btnSave = new JButton("Enregistrer playlist...");
        JButton btnOpen = new JButton("Ouvrir playlist (M3U8)");

        btnSave.addActionListener(e -> savePlaylistDialog());
        btnOpen.addActionListener(e -> openPlaylistDialog());

        panel.add(btnSave);
        panel.add(btnOpen);

        return panel;
    }

    // ==================================================================
    // CONFIGURATION UI (renderers + listeners)
    // ==================================================================

    /**
     * Configure le rendu des éléments affichés dans les {@link JList}.
     *
     * <p>
     * L'objectif est d'afficher uniquement le nom du fichier MP3 (et non
     * la représentation par défaut d'un objet Java).
     * </p>
     */
    private void setupRenderers() {
        DefaultListCellRenderer renderer = new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(
                    JList<?> list, Object value, int index,
                    boolean isSelected, boolean cellHasFocus) {

                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof FichierMp3 mp3) {
                    setText(mp3.getNomFichier());
                }
                return this;
            }
        };

        libraryList.setCellRenderer(renderer);
        playlistList.setCellRenderer(renderer);
    }

    /**
     * Installe les écouteurs d'événements de l'interface.
     *
     * <p>
     * Actuellement :
     * </p>
     * <ul>
     *   <li>sélection dans la bibliothèque → affichage des métadonnées</li>
     * </ul>
     */
    private void setupListeners() {
        libraryList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                FichierMp3 mp3 = libraryList.getSelectedValue();
                if (mp3 != null) {
                    showMetadata(mp3);
                }
            }
        });
    }

    // ==================================================================
    // SYNCHRONISATION VUE ↔ OBJET PLAYLIST
    // ==================================================================

    /**
     * Met à jour la liste Swing de playlist ({@link #playlistModel}) à partir
     * de l'objet {@link #currentPlaylist}.
     *
     * <p>
     * Cette méthode est appelée après :
     * </p>
     * <ul>
     *   <li>ajout d'éléments</li>
     *   <li>suppression d'éléments</li>
     *   <li>import d'une playlist</li>
     *   <li>réinitialisation</li>
     * </ul>
     */
    private void refreshPlaylistViewFromObject() {
        playlistModel.clear();
        for (FichierMp3 mp3 : currentPlaylist.getMorceaux()) {
            playlistModel.addElement(mp3);
        }
    }

    // ==================================================================
    // ACTIONS : dossier / bibliothèque
    // ==================================================================

    /**
     * Ouvre une boîte de dialogue pour sélectionner un dossier
     * puis lance son exploration afin d'alimenter la bibliothèque.
     */
    private void chooseAndExploreDirectory() {
        JFileChooser fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);

        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            exploreDirectory(fc.getSelectedFile());
        }
    }

    /**
     * Explore un dossier (récursivement via {@link Repertoires}) et remplit la bibliothèque.
     *
     * @param dir dossier à explorer
     */
    private void exploreDirectory(File dir) {
        if (dir == null || !dir.isDirectory()) {
            JOptionPane.showMessageDialog(this, "Dossier invalide.", "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        currentDirectory = dir;
        libraryModel.clear();

        Repertoires rep = new Repertoires(dir.getAbsolutePath());
        for (FichierMp3 mp3 : rep.getFichiersMp3()) {
            libraryModel.addElement(mp3);
        }

        if (libraryModel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Aucun MP3 trouvé dans ce dossier.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // ==================================================================
    // ACTIONS : métadonnées
    // ==================================================================

    /**
     * Ouvre une boîte de dialogue pour sélectionner un fichier MP3
     * puis affiche ses métadonnées.
     */
    private void chooseAndShowMp3Metadata() {
        JFileChooser fc = new JFileChooser();
        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);

        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File f = fc.getSelectedFile();
            if (f == null || !f.isFile()) return;
            showMetadata(new FichierMp3(f));
        }
    }

    /**
     * Affiche les métadonnées d'un fichier MP3 dans le panneau "Métadonnées".
     *
     * <p>
     * Cette méthode :
     * </p>
     * <ul>
     *   <li>met à jour les labels texte</li>
     *   <li>affiche une miniature de cover si elle existe</li>
     * </ul>
     *
     * @param mp3 fichier MP3 dont on souhaite afficher les métadonnées
     */
    private void showMetadata(FichierMp3 mp3) {
        if (mp3 == null || mp3.getCheminFichier() == null) return;

        lblFile.setText("Fichier : " + mp3.getCheminFichier().getAbsolutePath());

        Metadonnees meta = mp3.getMetadonnees();
        if (meta == null) {
            JOptionPane.showMessageDialog(this, "Impossible de lire les métadonnées.", "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        lblTitle.setText("Titre : " + meta.getTitre());
        lblArtist.setText("Artiste : " + meta.getArtiste());
        lblAlbum.setText("Album : " + meta.getAlbum());
        lblYear.setText("Année : " + meta.getAnnee());
        lblDuration.setText("Durée : " + meta.getDuree());
        lblCover.setText("Cover : " + (meta.containCover() ? "Oui" : "Non"));

        if (meta.containCover() && meta.getCoverBytes() != null) {
            ImageIcon icon = createThumbnail(meta.getCoverBytes(), 160, 160);
            if (icon != null) {
                coverLabel.setIcon(icon);
                coverLabel.setText(null);
            } else {
                coverLabel.setIcon(null);
                coverLabel.setText("Cover non décodable");
            }
        } else {
            coverLabel.setIcon(null);
            coverLabel.setText("Aucune cover");
        }

        coverLabel.revalidate();
        coverLabel.repaint();
    }

    // ==================================================================
    // ACTIONS : playlist (ajout / retrait / défaut / reset)
    // ==================================================================

    /**
     * Ajoute à la playlist tous les fichiers sélectionnés dans la bibliothèque.
     */
    private void addSelectedToPlaylist() {
        for (FichierMp3 mp3 : libraryList.getSelectedValuesList()) {
            currentPlaylist.ajouterMusique(mp3);
        }
        refreshPlaylistViewFromObject();
    }

    /**
     * Supprime de la playlist tous les fichiers sélectionnés dans la liste playlist.
     */
    private void removeSelectedFromPlaylist() {
        for (FichierMp3 mp3 : playlistList.getSelectedValuesList()) {
            currentPlaylist.supprimerMusique(mp3);
        }
        refreshPlaylistViewFromObject();
    }

    /**
     * Construit une playlist par défaut à partir du dossier courant en utilisant
     * {@link GestionPlaylist#creerPlaylistParDefaut(String, Repertoires)}.
     *
     * <p>
     * Si aucun dossier n'a été sélectionné, l'action est ignorée.
     * </p>
     */
    private void buildDefaultPlaylistFromCurrentDir() {
        if (currentDirectory == null) {
            JOptionPane.showMessageDialog(this, "Choisissez d'abord un dossier.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Repertoires rep = new Repertoires(currentDirectory.getAbsolutePath());
        currentPlaylist = gestionPlaylist.creerPlaylistParDefaut("Playlist par défaut", rep);
        refreshPlaylistViewFromObject();

        JOptionPane.showMessageDialog(this,
                "Playlist par défaut créée (" + currentPlaylist.getTaille() + " morceaux).",
                "OK",
                JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Réinitialise la playlist courante à une playlist vide.
     */
    private void clearPlaylist() {
        currentPlaylist = new Playlist("Playlist GUI");
        refreshPlaylistViewFromObject();
    }

    // ==================================================================
    // ACTIONS : import/export playlist
    // ==================================================================

    /**
     * Ouvre une boîte de dialogue d'enregistrement et exporte la playlist courante
     * dans le format choisi par l'utilisateur.
     */
    private void savePlaylistDialog() {
        if (currentPlaylist.getTaille() == 0) {
            JOptionPane.showMessageDialog(this, "Playlist vide : rien à enregistrer.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        FormatPlaylist format = (FormatPlaylist) JOptionPane.showInputDialog(
                this,
                "Choisir le format :",
                "Format playlist",
                JOptionPane.QUESTION_MESSAGE,
                null,
                FormatPlaylist.values(),
                FormatPlaylist.M3U8
        );
        if (format == null) return;

        JFileChooser fc = new JFileChooser();
        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);

        fc.setSelectedFile(new File("playlist." + format.name().toLowerCase()));

        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File out = fc.getSelectedFile();
        if (out == null) return;

        gestionPlaylist.enregistrerDansFichier(currentPlaylist, format, out.getAbsolutePath());
        JOptionPane.showMessageDialog(this, "Playlist enregistrée : " + out.getAbsolutePath(), "OK", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Ouvre une boîte de dialogue pour sélectionner une playlist au format M3U8,
     * la charge via {@link PlaylistIO}, puis remplace la playlist courante.
     */
    private void openPlaylistDialog() {
        JFileChooser fc = new JFileChooser();
        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);

        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File in = fc.getSelectedFile();
        if (in == null || !in.isFile()) return;

        try {
            Playlist loaded = playlistIO.loadM3U8(in);
            currentPlaylist = loaded;
            refreshPlaylistViewFromObject();

            JOptionPane.showMessageDialog(this,
                    "Playlist chargée (" + currentPlaylist.getTaille() + " morceaux).",
                    "OK",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur ouverture playlist : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==================================================================
    // ACTIONS : export métadonnées TXT
    // ==================================================================

    /**
     * Enregistre les métadonnées actuellement affichées dans un fichier texte UTF-8.
     *
     * <p>
     * Le contenu est une concaténation simple des labels affichés.
     * </p>
     */
    private void saveDisplayedMetadataToTxt() {
        String fileLine = lblFile.getText();
        if (fileLine == null || !fileLine.startsWith("Fichier : ")) {
            JOptionPane.showMessageDialog(this, "Aucun fichier sélectionné.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Enregistrer les métadonnées (TXT)");
        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);
        fc.setSelectedFile(new File("metadonnees.txt"));

        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;

        File out = fc.getSelectedFile();
        if (out == null) return;

        String content =
                lblFile.getText() + "\n" +
                lblTitle.getText() + "\n" +
                lblArtist.getText() + "\n" +
                lblAlbum.getText() + "\n" +
                lblYear.getText() + "\n" +
                lblDuration.getText() + "\n" +
                lblCover.getText() + "\n";

        try {
            Files.writeString(out.toPath(), content, StandardCharsets.UTF_8);
            JOptionPane.showMessageDialog(this, "Métadonnées enregistrées : " + out.getAbsolutePath(), "OK", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur écriture : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==================================================================
    // UTILITAIRES : images
    // ==================================================================

    /**
     * Crée une miniature (thumbnail) à partir d'une image brute.
     *
     * <p>
     * Étapes :
     * </p>
     * <ol>
     *   <li>décodage du tableau d'octets en {@link BufferedImage}</li>
     *   <li>calcul du facteur d'échelle pour respecter {@code maxW} et {@code maxH}</li>
     *   <li>redimensionnement via {@link Image#getScaledInstance(int, int, int)}</li>
     * </ol>
     *
     * @param imageBytes tableau d'octets représentant l'image (ex : JPEG/PNG)
     * @param maxW largeur maximale de la miniature
     * @param maxH hauteur maximale de la miniature
     * @return une {@link ImageIcon} redimensionnée, ou {@code null} si l'image est invalide
     */
    private ImageIcon createThumbnail(byte[] imageBytes, int maxW, int maxH) {
        try {
            if (imageBytes == null || imageBytes.length == 0) return null;

            ByteArrayInputStream in = new ByteArrayInputStream(imageBytes);
            BufferedImage img = ImageIO.read(in);
            if (img == null) return null;

            int w = img.getWidth();
            int h = img.getHeight();
            double scale = Math.min((double) maxW / w, (double) maxH / h);

            int newW = (int) (w * scale);
            int newH = (int) (h * scale);

            Image scaled = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);

        } catch (Exception e) {
            return null;
        }
    }
}
