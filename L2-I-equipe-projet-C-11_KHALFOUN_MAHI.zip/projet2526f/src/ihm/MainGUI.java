package ihm;

import javax.swing.*;

/**
 * Point d'entrée principal de l'application en mode graphique (GUI).
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe contient la méthode {@code main} permettant de lancer
 * l'application avec une interface graphique basée sur Swing.
 * </p>
 *
 * <p>
 * Elle s'assure que l'initialisation et l'affichage de l'interface
 * graphique sont effectués dans le
 * <strong>thread de dispatch des événements Swing</strong>
 * (Event Dispatch Thread – EDT), conformément aux bonnes pratiques Swing.
 * </p>
 *
 * <h2>Initialisation graphique</h2>
 * <p>
 * Avant de créer la fenêtre principale, la classe tente d'appliquer
 * le <em>Look &amp; Feel</em> du système afin d'assurer une intégration
 * visuelle cohérente avec le système d'exploitation de l'utilisateur.
 * </p>
 *
 * <h2>Architecture</h2>
 * <ul>
 *   <li>{@code MainGUI} : point d'entrée graphique</li>
 *   <li>{@link GUI} : fenêtre principale de l'application</li>
 * </ul>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class MainGUI {

    /**
     * Méthode principale appelée par la JVM pour lancer l'application
     * en mode graphique.
     *
     * <p>
     * L'utilisation de {@link SwingUtilities#invokeLater(Runnable)}
     * garantit que toute la logique Swing est exécutée dans le
     * thread approprié.
     * </p>
     *
     * @param args arguments de la ligne de commande (non utilisés ici)
     */
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            try {
                UIManager.setLookAndFeel(
                        UIManager.getSystemLookAndFeelClassName()
                );
            } catch (Exception ignored) {
                // En cas d'échec, le Look & Feel par défaut est conservé
            }

            GUI frame = new GUI();
            frame.setVisible(true);
        });
    }
}
