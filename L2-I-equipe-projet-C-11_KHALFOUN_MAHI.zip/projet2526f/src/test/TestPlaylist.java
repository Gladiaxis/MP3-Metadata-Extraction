package test;

import gestionnaireFichiers.Repertoires;
import gestionnaireFichiers.FichierMp3;
import playlist.GestionPlaylist;
import playlist.Playlist;
import playlist.FormatPlaylist;

import java.nio.file.Path;

/**
 * Classe de test permettant de valider la création et l’export de playlists.
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe est utilisée à des fins de test afin de vérifier :
 * </p>
 * <ul>
 *   <li>l’exploration d’un répertoire contenant des fichiers MP3,</li>
 *   <li>la création d’une playlist par défaut à partir de ce répertoire,</li>
 *   <li>l’export de cette playlist dans plusieurs formats standards
 *       (M3U8, XSPF, JSPF).</li>
 * </ul>
 *
 * <h2>Contexte d’utilisation</h2>
 * <p>
 * {@code TestPlaylist} n’est pas destinée à être utilisée dans
 * l’application finale (CLI ou GUI).
 * Elle sert uniquement :
 * </p>
 * <ul>
 *   <li>au développement,</li>
 *   <li>à la validation du comportement des classes métier,</li>
 *   <li>au débogage et aux essais de formats d’export.</li>
 * </ul>
 *
 * <h2>Fonctionnement général</h2>
 * <ol>
 *   <li>exploration d’un dossier contenant des MP3 via {@link Repertoires},</li>
 *   <li>création d’une {@link Playlist} par défaut,</li>
 *   <li>affichage de son contenu dans la console,</li>
 *   <li>export de la playlist dans le dossier exploré.</li>
 * </ol>
 *
 * <h2>Remarque</h2>
 * <p>
 * Le chemin du dossier contenant les fichiers MP3 est actuellement
 * codé en dur et devra être adapté selon l’environnement de test.
 * </p>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class TestPlaylist {

    /**
     * Point d’entrée de la classe de test.
     *
     * <p>
     * La méthode réalise les actions suivantes :
     * </p>
     * <ol>
     *   <li>définit un chemin vers un dossier contenant des fichiers MP3,</li>
     *   <li>explore ce dossier pour détecter les fichiers audio,</li>
     *   <li>crée une playlist par défaut à partir des fichiers trouvés,</li>
     *   <li>affiche les informations de la playlist dans la console,</li>
     *   <li>génère et enregistre la playlist dans plusieurs formats.</li>
     * </ol>
     *
     * <p>
     * Les fichiers générés sont enregistrés directement dans le dossier
     * exploré, avec des noms construits à partir du nom de la playlist.
     * </p>
     *
     * @param args arguments de la ligne de commande (non utilisés)
     */
    public static void main(String[] args) {

        // Chemin du dossier contenant les fichiers MP3 (à adapter si nécessaire)
        String chemin = "C:/Users/AdelM/Music";

        // Exploration du répertoire
        Repertoires rep = new Repertoires(chemin);

        // Création d'une playlist par défaut
        GestionPlaylist gestion = new GestionPlaylist();
        Playlist playlist = gestion.creerPlaylistParDefaut(
                "Ma Playlist par défaut", rep
        );

        // Affichage des informations de la playlist
        System.out.println("=== PLAYLIST CRÉÉE ===");
        System.out.println("Nom : " + playlist.getNom());
        System.out.println("Nombre de morceaux : " + playlist.getTaille());
        for (FichierMp3 f : playlist.getMorceaux()) {
            System.out.println(" - " + f.getNomFichier());
        }

        // Dossier racine sous forme de Path
        Path baseDir = rep.getRacine().toPath();

        // Construction de noms de fichiers propres à partir du nom de la playlist
        String baseName = playlist.getNom().replaceAll("\\s+", "_");

        Path m3u8Path = baseDir.resolve("playlist_" + baseName + ".m3u8");
        Path xspfPath = baseDir.resolve("playlist_" + baseName + ".xspf");
        Path jspfPath = baseDir.resolve("playlist_" + baseName + ".jspf");

        // Enregistrement de la playlist dans les différents formats
        gestion.enregistrerDansFichier(
                playlist, FormatPlaylist.M3U8, m3u8Path.toString()
        );
        gestion.enregistrerDansFichier(
                playlist, FormatPlaylist.XSPF, xspfPath.toString()
        );
        gestion.enregistrerDansFichier(
                playlist, FormatPlaylist.JSPF, jspfPath.toString()
        );
    }
}
