package test;

import gestionnaireFichiers.FichierMp3;
import gestionnaireFichiers.Repertoires;

/**
 * Classe de test permettant de valider l’exploration d’un répertoire
 * contenant des fichiers MP3.
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe est utilisée pour vérifier le bon fonctionnement de la
 * classe {@link Repertoires}, notamment :
 * </p>
 * <ul>
 *   <li>la détection des fichiers MP3 dans un répertoire,</li>
 *   <li>l’exploration récursive des sous-répertoires,</li>
 *   <li>le filtrage des fichiers non audio.</li>
 * </ul>
 *
 * <h2>Contexte d’utilisation</h2>
 * <p>
 * {@code TestRepertoire} est une classe de test interne.
 * Elle n’est pas destinée à être utilisée dans l’application finale
 * (CLI ou GUI), mais uniquement lors :
 * </p>
 * <ul>
 *   <li>du développement,</li>
 *   <li>du débogage,</li>
 *   <li>de la validation du parcours de fichiers.</li>
 * </ul>
 *
 * <h2>Fonctionnement</h2>
 * <ol>
 *   <li>définition d’un chemin vers un dossier contenant des MP3,</li>
 *   <li>création d’un objet {@link Repertoires} pour explorer ce dossier,</li>
 *   <li>affichage dans la console des fichiers MP3 trouvés.</li>
 * </ol>
 *
 * <h2>Remarque</h2>
 * <p>
 * Le chemin du répertoire est actuellement codé en dur.
 * Il devra être adapté selon l’environnement de test.
 * </p>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class TestRepertoire {

    /**
     * Point d’entrée de la classe de test.
     *
     * <p>
     * La méthode :
     * </p>
     * <ul>
     *   <li>explore un répertoire donné,</li>
     *   <li>récupère la liste des fichiers MP3 détectés,</li>
     *   <li>affiche le nom de chaque fichier dans la console.</li>
     * </ul>
     *
     * @param args arguments de la ligne de commande (non utilisés)
     */
    public static void main(String[] args) {

        // Chemin du répertoire contenant les fichiers MP3 (à adapter)
        String chemin = "C:/Users/AdelM/Music";

        // Exploration du répertoire
        Repertoires rep = new Repertoires(chemin);

        // Affichage des fichiers MP3 trouvés
        System.out.println("\n--- Fichiers MP3 trouvés ---");
        for (FichierMp3 file : rep.getFichiersMp3()) {
            System.out.println(" - " + file.getNomFichier());
        }
    }
}
