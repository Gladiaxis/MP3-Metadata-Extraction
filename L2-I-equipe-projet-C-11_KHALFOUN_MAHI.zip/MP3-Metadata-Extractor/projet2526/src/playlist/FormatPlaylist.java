package playlist;

public enum FormatPlaylist {
    XSPF,
    JSPF,
    M3U8
}
