package playlist;

import java.util.ArrayList;

import gestionnaireFichiers.Repertoires;
import gestionnaireFichiers.FichierMp3;
import metadonnees.Metadonnees;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;


/**
 * La classe GestionPlaylist est chargée de :
 *  - constituer des playlists à partir d'un répertoire (Repertoires),
 *  - exporter ces playlists dans différents formats : M3U8, XSPF, JSPF.
 */
public class GestionPlaylist {

    /**
     * Crée une playlist par défaut contenant tous les fichiers MP3
     * trouvés dans l'objet Repertoires donné.
     *
     * @param nom Nom de la playlist
     * @param rep Objet Repertoires déjà initialisé
     * @return une Playlist contenant tous les FichierMp3 du répertoire
     */
    public Playlist creerPlaylistParDefaut(String nom, Repertoires rep) {
        Playlist playlist = new Playlist(nom);
        ArrayList<FichierMp3> fichiers = rep.getFichiersMp3();

        for (FichierMp3 f : fichiers) {
            playlist.ajouterMusique(f);
        }

        return playlist;
    }



    // ---------------------------------------------------------------------
    // EXPORT AVEC L'ENUM FormatPlaylist
    // ---------------------------------------------------------------------

    /**
     * Exporte une playlist dans le format demandé.
     *
     * @param playlist la playlist à exporter
     * @param format   le format désiré (XSPF, JSPF, M3U8)
     * @return une chaîne de caractères représentant la playlist dans ce format
     */
    public String exporterPlaylist(Playlist playlist, FormatPlaylist format) {
        switch (format) {
            case M3U8:
                return exporterM3U8(playlist);
            case XSPF:
                return exporterXSPF(playlist);
            case JSPF:
                return exporterJSPF(playlist);
            default:
                // normallement impossible car enum limité aux 3 valeurs
                throw new IllegalArgumentException("Format de playlist non supporté : " + format);
        }
    }

    // ---------------------------------------------------------------------
    // EXPORT M3U8
    // ---------------------------------------------------------------------

    /**
     * Génère le contenu texte d'une playlist au format M3U8.
     *
     *   chemin/vers/fichier1.mp3
     *   chemin/vers/fichier2.mp3
     *
     * @param playlist Playlist à exporter
     * @return contenu M3U8
     */
    private String exporterM3U8(Playlist playlist) {
        StringBuilder sb = new StringBuilder();

        sb.append("#EXTM3U\n");

        for (FichierMp3 f : playlist.getMorceaux()) {
            sb.append(f.getCheminFichier().getAbsolutePath()).append("\n");
        }

        return sb.toString();
    }

    // ---------------------------------------------------------------------
    // EXPORT XSPF (XML)
    // ---------------------------------------------------------------------

    /**
     * Génère le contenu texte d'une playlist au format XSPF (XML).
     *
     * @param playlist Playlist à exporter
     * @return contenu XSPF
     */
    private String exporterXSPF(Playlist playlist) {
        StringBuilder sb = new StringBuilder();

        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        sb.append("<playlist version=\"1\" xmlns=\"http://xspf.org/ns/0/\">\n");
        sb.append("  <title>").append(echapperXml(playlist.getNom())).append("</title>\n");
        sb.append("  <trackList>\n");

        for (FichierMp3 f : playlist.getMorceaux()) {
            String chemin = f.getCheminFichier().getAbsolutePath();
            String uri = "file:///" + chemin.replace("\\", "/");

            Metadonnees meta = f.getMetadonnees();

            sb.append("    <track>\n");
            sb.append("      <location>").append(echapperXml(uri)).append("</location>\n");

            if (meta != null) {
                String titre   = meta.getTitre();
                String artiste = meta.getArtiste();
                String album   = meta.getAlbum();

                if (titre != null && !titre.isEmpty()) {
                    sb.append("      <title>").append(echapperXml(titre)).append("</title>\n");
                }
                if (artiste != null && !artiste.isEmpty()) {
                    sb.append("      <creator>").append(echapperXml(artiste)).append("</creator>\n");
                }
                if (album != null && !album.isEmpty()) {
                    sb.append("      <album>").append(echapperXml(album)).append("</album>\n");
                }
            }

            sb.append("    </track>\n");
        }

        sb.append("  </trackList>\n");
        sb.append("</playlist>\n");

        return sb.toString();
    }

    // ---------------------------------------------------------------------
    // EXPORT JSPF (JSON)
    // ---------------------------------------------------------------------

    /**
     * Génère le contenu texte d'une playlist au format JSPF (JSON Playlist Format).
     *
     * @param playlist Playlist à exporter
     * @return contenu JSPF
     */
    private String exporterJSPF(Playlist playlist) {
        StringBuilder sb = new StringBuilder();

        sb.append("{\n");
        sb.append("  \"playlist\": {\n");
        sb.append("    \"title\": \"").append(echapperJson(playlist.getNom())).append("\",\n");
        sb.append("    \"track\": [\n");

        ArrayList<FichierMp3> morceaux = playlist.getMorceaux();
        for (int i = 0; i < morceaux.size(); i++) {
            FichierMp3 f = morceaux.get(i);
            String chemin = f.getCheminFichier().getAbsolutePath();
            String uri = "file:///" + chemin.replace("\\", "/");

            Metadonnees meta = f.getMetadonnees();

            sb.append("      {\n");
            sb.append("        \"location\": \"").append(echapperJson(uri)).append("\"");

            if (meta != null) {
                String titre   = meta.getTitre();
                String artiste = meta.getArtiste();
                String album   = meta.getAlbum();

                if (titre != null && !titre.isEmpty()) {
                    sb.append(",\n        \"title\": \"")
                            .append(echapperJson(titre)).append("\"");
                }
                if (artiste != null && !artiste.isEmpty()) {
                    sb.append(",\n        \"creator\": \"")
                            .append(echapperJson(artiste)).append("\"");
                }
                if (album != null && !album.isEmpty()) {
                    sb.append(",\n        \"album\": \"")
                            .append(echapperJson(album)).append("\"");
                }
            }

            sb.append("\n      }");
            if (i < morceaux.size() - 1) {
                sb.append(",");
            }
            sb.append("\n");
        }

        sb.append("    ]\n");
        sb.append("  }\n");
        sb.append("}\n");

        return sb.toString();
    }

    // ---------------------------------------------------------------------
    // Méthodes utilitaires pour échapper XML / JSON
    // ---------------------------------------------------------------------

    private String echapperXml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    private String echapperJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }


    /**
     * Exporte la playlist dans un fichier selon le format demandé.
     *
     * @param playlist      la playlist à exporter
     * @param format        le format (M3U8, XSPF, JSPF)
     * @param cheminFichier chemin du fichier de sortie (ex: "playlist.m3u8")
     */
    public void enregistrerDansFichier(Playlist playlist, FormatPlaylist format, String cheminFichier) {
        try {
            String contenu = exporterPlaylist(playlist, format);
            Path path = Paths.get(cheminFichier);
            Files.write(path, contenu.getBytes(StandardCharsets.UTF_8));
            System.out.println("Playlist enregistrée dans : " + path.toAbsolutePath());
        } catch (Exception e) {
            System.err.println("Erreur lors de l'écriture de la playlist dans le fichier : " + cheminFichier);
            e.printStackTrace();
        }
    }

}
