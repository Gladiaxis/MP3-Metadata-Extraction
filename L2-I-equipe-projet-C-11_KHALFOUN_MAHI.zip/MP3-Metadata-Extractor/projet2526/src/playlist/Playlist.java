package playlist;

import java.util.ArrayList;
import gestionnaireFichiers.FichierMp3;

/**
 * La classe Playlist représente une liste de morceaux audio (FichierMp3)
 * associée à un nom.
 *
 * Elle permet :
 *  - de créer une playlist vide avec un nom,
 *  - d'ajouter/supprimer des musiques,
 *  - de récupérer la liste des morceaux,
 *  - d'obtenir quelques infos (taille, etc.).
 */
public class Playlist {

    /** Nom de la playlist (ex : "Ma playlist par défaut"). */
    private String nom;

    /** Liste des morceaux (fichiers MP3) de la playlist. */
    private ArrayList<FichierMp3> morceaux;

    /**
     * Constructeur : crée une playlist vide avec le nom donné.
     *
     * @param nom Nom de la playlist
     */
    public Playlist(String nom) {
        this.nom = nom;
        this.morceaux = new ArrayList<>();
    }

    /**
     * Retourne le nom de la playlist.
     */
    public String getNom() {
        return nom;
    }

    /**
     * Modifie le nom de la playlist.
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Retourne la liste des morceaux de la playlist.
     * La liste retournée est modifiable.)
     */
    public ArrayList<FichierMp3> getMorceaux() {
        return morceaux;
    }

    /**
     * Ajoute un morceau à la playlist.
     *
     * @param musique FichierMp3 à ajouter
     */
    public void ajouterMusique(FichierMp3 musique) {
        if (musique != null) {
            morceaux.add(musique);
        }
    }

    /**
     * Supprime un morceau de la playlist.
     *
     * @param musique FichierMp3 à supprimer
     * @return true si le morceau était présent et a été supprimé, false sinon
     */
    public boolean supprimerMusique(FichierMp3 musique) {
        if (musique == null) {
            return false;
        }
        return morceaux.remove(musique);
    }

    /**
     * Retourne le nombre de morceaux dans la playlist.
     */
    public int getTaille() {
        return morceaux.size();
    }

    /**
     * Retourne une représentation texte de la playlist :
     * son nom et la liste des fichiers.
     * On l'utilisera pour le GUI
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Playlist : ").append(nom).append("\n");
        sb.append("Nombre de morceaux : ").append(morceaux.size()).append("\n");

        for (int i = 0; i < morceaux.size(); i++) {
            FichierMp3 f = morceaux.get(i);
            sb.append(String.format("%02d - %s%n", i + 1, f.getNomFichier()));
        }

        return sb.toString();
    }
}
