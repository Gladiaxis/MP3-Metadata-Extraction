package test;
import gestionnaireFichiers.Repertoires;
import gestionnaireFichiers.FichierMp3;
import playlist.GestionPlaylist;
import playlist.Playlist;
import playlist.FormatPlaylist;



import gestionnaireFichiers.Repertoires;
import gestionnaireFichiers.FichierMp3;

import java.nio.file.Path;

public class TestPlaylist {

    public static void main(String[] args) {

        //Pour l'instant on ecris chemin dans lequel on place notre playlist, jvais modifier après
        String chemin = "C:/Users/AdelM/Music";



        Repertoires rep = new Repertoires(chemin);

        GestionPlaylist gestion = new GestionPlaylist();
        Playlist playlist = gestion.creerPlaylistParDefaut("Ma Playlist par défaut", rep);//jvais chercher une
                                                                                                //meilleur solution...

        System.out.println("=== PLAYLIST CRÉÉE ===");
        System.out.println("Nom : " + playlist.getNom());
        System.out.println("Nombre de morceaux : " + playlist.getTaille());
        for (FichierMp3 f : playlist.getMorceaux()) {
            System.out.println(" - " + f.getNomFichier());
        }

        // On récupère le dossier racine sous forme de Path
        Path baseDir = rep.getRacine().toPath();

        // On fabrique des noms de fichiers “propres”
        String baseName = playlist.getNom().replaceAll("\\s+", "_");

        Path m3u8Path = baseDir.resolve("playlist_" + baseName + ".m3u8");
        Path xspfPath = baseDir.resolve("playlist_" + baseName + ".xspf");
        Path jspfPath = baseDir.resolve("playlist_" + baseName + ".jspf");

        // Et on enregistre directement DANS ce dossier
        gestion.enregistrerDansFichier(playlist, FormatPlaylist.M3U8, m3u8Path.toString());
        gestion.enregistrerDansFichier(playlist, FormatPlaylist.XSPF, xspfPath.toString());
        gestion.enregistrerDansFichier(playlist, FormatPlaylist.JSPF, jspfPath.toString());
    }
}
