package test;

public class MainCLIApp {
    public static void main(String[] args) {

    }
}
