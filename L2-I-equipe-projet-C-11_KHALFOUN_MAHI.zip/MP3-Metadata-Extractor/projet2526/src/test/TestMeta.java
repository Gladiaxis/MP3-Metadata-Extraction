package test;
import gestionnaireFichiers.FichierMp3;
import java.io.File;
import metadonnees.Metadonnees;

public class TestMeta {
    public static void main(String[] args) {
        File f = new File("C:/Users/AdelM/Music/09 Tu sais");
        FichierMp3 m = new FichierMp3(f);

        Metadonnees meta = m.getMetadonnees();
        if (meta != null) {
            System.out.println(meta);

        } else {
            System.out.println("Impossible de lire les métadonnées.");
        }
    }
}
