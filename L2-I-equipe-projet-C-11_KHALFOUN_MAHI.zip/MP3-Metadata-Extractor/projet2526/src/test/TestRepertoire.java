package test;

import gestionnaireFichiers.FichierMp3;
import gestionnaireFichiers.Repertoires;

public class TestRepertoire {
    public static void main(String[] args) {

        String chemin = "C:/Users/AdelM/Music";

        Repertoires rep = new Repertoires(chemin);

        System.out.println("\n--- Fichiers MP3 trouvés ---");
        for (FichierMp3 file : rep.getFichiersMp3()) {
            // juste le nom :
            System.out.println("\n -"+file.getNomFichier());


        }
    }
}
