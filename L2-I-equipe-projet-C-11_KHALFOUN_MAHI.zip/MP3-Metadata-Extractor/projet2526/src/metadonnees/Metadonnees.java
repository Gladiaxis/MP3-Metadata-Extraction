package metadonnees;

import java.io.IOException;

/**
 * Pour l'instant, on choisit de travailler avec la librairie mp3agic. Il n'est pas impossible que l'on utilise
 * jaudiotagger par la suite.
 */


/**
 * On décide d'importer directement notre librairie externe dans notre classe Metadonnees.
 * Ce choix est celui qui nous semble le plus cohérent.
 */

//IMPORTS :
//----------------------------------------------------------------------------------------------------------------------
import com.mpatric.mp3agic.Mp3File;
import com.mpatric.mp3agic.ID3v1;
import com.mpatric.mp3agic.ID3v2;
import com.mpatric.mp3agic.InvalidDataException;
import com.mpatric.mp3agic.UnsupportedTagException;
//----------------------------------------------------------------------------------------------------------------------



public class Metadonnees {
    //ATTRIBUTS :
    //------------------------------------------------------------------------------------------------------------------
    /**
     * -Nos attributs sont les métadonnées que l'on souhaite afficher (que les principales pour l'instant ).
     * -On a rajouté la durée qui sera calculer, et un boolean hasCover qui indiquera si une image est associé au titre.
     */
    private String titre;
    private String artiste;
    private String album;
    private String annee;
    private String commentaire;
    private String duree;     // mm:ss
    private boolean hasCover;
    private byte[] coverBytes;




//----------------------------------------------------------------------------------------------------------------------


    //LE CONSTRUCTEUR :
    /**
     *
     * @param cheminFichier pour choisir le fichier duquel on veut extraire les métadonnées.
     * @throws IOException
     * @throws UnsupportedTagException
     * @throws InvalidDataException
     */
    public Metadonnees(String cheminFichier) throws IOException, UnsupportedTagException, InvalidDataException {
        Mp3File mp3 = new Mp3File(cheminFichier);


        //On calcule la durée ici pour comme ça c fait...
        long dureeSec = mp3.getLengthInSeconds();
        long minutes = dureeSec / 60;
        long secondes = dureeSec % 60;
        this.duree = String.format("%02d:%02d", minutes, secondes);

        String t = null;//titre
        String a = null;//artiste
        String al = null;//album
        String y = null;//année
        String c = null;//commentaires



        // 2) On extrait l'ID3v2 s'il existe
        if (mp3.hasId3v2Tag()) {
            ID3v2 id3v2Tag = mp3.getId3v2Tag();
            t = id3v2Tag.getTitle();
            a = id3v2Tag.getArtist();
            al = id3v2Tag.getAlbum();
            y = id3v2Tag.getYear();
            c = id3v2Tag.getComment();

            byte[] coverData = id3v2Tag.getAlbumImage();
            this.hasCover = (coverData != null && coverData.length > 0);
        } else {
            this.hasCover = false;
        }

        // 3) Sinon compléter avec ID3v1 si besoin
        if (mp3.hasId3v1Tag()) {
            ID3v1 id3v1Tag = mp3.getId3v1Tag();

            if (t == null || t.isEmpty())   t = id3v1Tag.getTitle();
            if (a == null || a.isEmpty())   a = id3v1Tag.getArtist();
            if (al == null || al.isEmpty()) al = id3v1Tag.getAlbum();
            if (y == null || y.isEmpty())   y = id3v1Tag.getYear();
            if (c == null || c.isEmpty())   c = id3v1Tag.getComment();
        }

        // 4) J'remplace les null par ""
        this.titre       = (t != null) ? t : "";
        this.artiste     = (a != null) ? a : "";
        this.album       = (al != null) ? al : "";
        this.annee       = (y != null) ? y : "";
        this.commentaire = (c != null) ? c : "";
    }
//----------------------------------------------------------------------------------------------------------------------


    //GETTERS :

    public String getTitre()       { return titre; }
    public String getArtiste()     { return artiste; }
    public String getAlbum()       { return album; }
    public String getAnnee()       { return annee; }
    public String getCommentaire() { return commentaire; }
    public String getDuree()       { return duree; }
    public boolean containCover()  { return hasCover; }
    public byte[] getCoverBytes()  {return coverBytes;}


    //SETTERS :
    public void setTitre(String titre)       { this.titre=titre; }
    public void setArtiste(String artiste)     { this.titre=artiste; }
    public void setAlbum(String album)       { this.titre=album; }
    public void setAnnee(String annee)       { this.titre=annee; }
    public void setCommentaire(String commentaire) { this.titre=commentaire; }

    @Override
    public String toString() {
        String coverMsg = hasCover ? "Oui" : "Non";
        return "Titre   : " + titre + "\n"
                + "Artiste : " + artiste + "\n"
                + "Album   : " + album + "\n"
                + "Année   : " + annee + "\n"
                + "Durée   : " + duree + "\n"
                + "Cover   : " + coverMsg;
    }
}
