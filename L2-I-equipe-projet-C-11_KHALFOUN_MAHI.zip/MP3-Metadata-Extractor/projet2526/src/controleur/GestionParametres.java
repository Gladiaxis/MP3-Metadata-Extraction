package controleur;

import gestionnaireFichiers.FichierMp3;
import gestionnaireFichiers.Repertoires;
import metadonnees.Metadonnees;
import playlist.GestionPlaylist;
import playlist.Playlist;
import playlist.FormatPlaylist;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class GestionParametres {


    private String action;   // "help", "metadata", "explorer", "playlist"
    private String fichier;  // pour -f
    private String dossier;  // pour -d
    private String format;   // format playlist (xspf, jspf, m3u8)
    private String sortie;   // chemin ou nom du fichier de sortie


    // CONSTRUCTEURS
    public GestionParametres(String action) {
        this.action = action;
    }

    public GestionParametres(String action, String param) {
        this(action);
        // Selon l'option, on range au bon endroit
        if ("-d".equals(action)) {
            this.dossier = param;
        } else if ("-f".equals(action)) {
            this.fichier = param;
        } else {
            // au cas où
            this.fichier = param;
        }
    }


    public GestionParametres(String action, String dossier, String format, String sortie) {
        this(action);
        this.dossier = dossier;
        this.format = format;
        this.sortie = sortie;
    }

    // --------------------------------------------------
    // POINT D’ENTRÉE : exécution de l’action
    // --------------------------------------------------

    public String execute() {

        switch (action) {

            case "-h":
            case "--help":
                return afficherAide();

            case "-f":
                return extraireMetadonnees(fichier);

            case "-d":
                return explorerRepertoire(dossier);

            case "playlist":
                return genererPlaylist(dossier, format, sortie);

            default:
                return "Erreur : commande inconnue.";
        }
    }

    // --------------------------------------------------
    // AIDE
    // --------------------------------------------------

    public String afficherAide() {
        return """
               Commandes disponibles :

               -h | --help
                   Affiche cette aide.

               -f "fichier.mp3"
                   Extrait et affiche les métadonnées du fichier MP3.

               -d <répertoire>
                   Liste tous les fichiers MP3 présents dans le répertoire.

               -d <répertoire> --<format> -o <fichier.sortie>
                   Génère une playlist à partir du répertoire.
                   Formats possibles : --xspf, --jspf, --m3u8

               Exemples :
                   -f "titre.mp3"
                   -d .
                   -d . --m3u8 -o ./nvlPlaylist.m3u8
               """;
    }

    // --------------------------------------------------
    // 1) METADATA : -f <fichier.mp3>
    // --------------------------------------------------

    private String extraireMetadonnees(String cheminFichier) {
        if (cheminFichier == null) {
            return "Erreur : aucun fichier spécifié.";
        }

        File f = new File(cheminFichier);
        if (!f.exists() || !f.isFile()) {
            return "Erreur : le fichier n'existe pas : " + cheminFichier;
        }

        // On part du principe qu'on a un constructeur FichierMp3(File)
        FichierMp3 mp3 = new FichierMp3(f);
        Metadonnees meta = mp3.getMetadonnees();

        if (meta == null) {
            return "Impossible de lire les métadonnées pour : " + cheminFichier;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Fichier : ").append(f.getAbsolutePath()).append("\n");
        sb.append("Titre   : ").append(meta.getTitre()).append("\n");
        sb.append("Artiste : ").append(meta.getArtiste()).append("\n");
        sb.append("Album   : ").append(meta.getAlbum()).append("\n");
        sb.append("Année   : ").append(meta.getAnnee()).append("\n");
        sb.append("Durée   : ").append(meta.getDuree()).append("\n");
        sb.append("Pochette: ").append(meta.containCover() ? "oui" : "non").append("\n");

        return sb.toString();
    }

    // --------------------------------------------------
    // 2) EXPLORER : -d <répertoire>
    // --------------------------------------------------

    private String explorerRepertoire(String cheminDossier) {


        if (cheminDossier == null) {
            return "Erreur : aucun répertoire spécifié.";
        }

        Repertoires rep = new Repertoires(cheminDossier);

        List<FichierMp3> fichiers = rep.getFichiersMp3();

        if (fichiers.isEmpty()) {
            return "Aucun fichier MP3 trouvé dans : " + cheminDossier;
        }

        StringBuilder sb = new StringBuilder("Fichiers MP3 trouvés dans ");
        sb.append(cheminDossier).append(" :\n");

        for (FichierMp3 f : fichiers) {
            sb.append("- ").append(f.getNomFichier()).append("\n");
        }

        return sb.toString();
    }

    // --------------------------------------------------
    // 3) PLAYLIST : -d <dossier> --<format> -o <sortie>
    // --------------------------------------------------

    private String genererPlaylist(String cheminDossier, String formatStr, String fichierSortie) {

        if (cheminDossier == null) {
            return "Erreur : aucun répertoire spécifié.";
        }
        if (formatStr == null) {
            return "Erreur : aucun format de playlist spécifié (xspf, jspf, m3u8).";
        }
        if (fichierSortie == null) {
            return "Erreur : aucun fichier de sortie spécifié.";
        }

        // 1) Explorer le répertoire et créer la playlist
        Repertoires rep = new Repertoires(cheminDossier);
        GestionPlaylist gp = new GestionPlaylist();
        Playlist playlist = gp.creerPlaylistParDefaut("Playlist CLI", rep);

        if (playlist.getTaille() == 0) {
            return "Impossible de créer une playlist : aucun MP3 trouvé dans " + cheminDossier;
        }

        // 2) Format : args te donnent "xspf", "jspf" ou "m3u8"
        FormatPlaylist formatEnum;
        try {
            formatEnum = FormatPlaylist.valueOf(formatStr.toUpperCase()); // "xspf" -> XSPF
        } catch (IllegalArgumentException e) {
            return "Format de playlist inconnu : " + formatStr
                    + ". Formats possibles : xspf, jspf, m3u8.";
        }

        // 3) Générer le contenu texte de la playlist
        String contenu = gp.exporterPlaylist(playlist, formatEnum);

        // 4) Écrire dans le fichier de sortie
        try {
            Path out = Paths.get(fichierSortie);
            Files.write(out, contenu.getBytes(StandardCharsets.UTF_8));
            return "Playlist générée avec succès : "
                    + out.toAbsolutePath() + " (format " + formatEnum + ").";
        } catch (IOException e) {
            return "Erreur lors de l'écriture de la playlist dans '" + fichierSortie
                    + "' : " + e.getMessage();
        }
    }


}
