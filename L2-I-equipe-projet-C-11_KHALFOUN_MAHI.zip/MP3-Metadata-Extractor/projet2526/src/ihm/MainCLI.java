package ihm;

/**Pour une utilisation plus simple, il faut que le cli.jar soit dans le répertoire Music
 *
  */

public class MainCLI {
    public static void main(String[] args) {
        ihm.CLI cli = new ihm.CLI();
        cli.run(args);
    }
}
