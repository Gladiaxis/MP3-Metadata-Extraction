package ihm;

import controleur.GestionParametres;

/**
 * CLI : Interface en ligne de commande (mode console).
 *
 * Commandes :
 *  -h | --help
 *  -f <fichier.mp3>
 *  -d <repertoire>               (ex: -d .)
 *  -d <repertoire> --<format> -o <sortie>
 *      formats : --xspf, --jspf, --m3u8
 *
 * Exemples :
 *  java -jar cli.jar -h
 *  java -jar cli.jar -f "musiques/09 Tu sais pas.mp3"
 *  java -jar cli.jar -d .
 *  java -jar cli.jar -d . --m3u8 -o playlist.m3u8
 */
public class CLI implements IHM {

    public CLI() {}

    public void run(String[] args) {


        GestionParametres gestion = analyserArguments(args);

        // Ici, ta logique renvoie un message final à afficher
        String resultat = gestion.execute();

        // Affichage (résultat ou erreurs ont pu être imprimées pendant l'analyse)
        afficherResultat(resultat);
    }

    // --------------------------------------------------
    // Méthodes de l'interface IHM
    // --------------------------------------------------

    @Override
    public void afficherResultat(String message) {
        System.out.println(message);
    }

    @Override
    public void afficherErreur(String message) {
        System.err.println(message);
    }

    // --------------------------------------------------
    // Analyse des arguments utilisateur
    // --------------------------------------------------

    private GestionParametres analyserArguments(String[] args) {


        if (args == null || args.length == 0) {
            // Quand rien n'est fourni, on affiche l'aide via l'option help
            return new GestionParametres("-h");
        }

        String option = args[0];

        switch (option) {

            case "-h":
            case "--help":
                return new GestionParametres("-h"); // ou "--help", mais "-h" suffit

            case "-f":
                if (args.length != 2) {
                    afficherErreur("Usage : -f 'fichier.mp3'");
                    return new GestionParametres("-h");
                }
                return new GestionParametres("-f", args[1]);

            case "-d":
                // Usage 1: -d <dossier>
                if (args.length == 2) {
                    return new GestionParametres("-d", args[1]);
                }

                // Usage 2: -d <dossier> --<format> -o <sortie>
                if (args.length == 5 && args[3].equals("-o") && estFormat(args[2])) {
                    String format = args[2].substring(2); // "--xspf" -> "xspf"
                    String dossier = args[1];
                    String sortie  = args[4];
                    return new GestionParametres("playlist", dossier, format, sortie);
                }

                afficherErreur("Usage : -d <dossier> OU -d <dossier> --<format> -o <sortie>");
                afficherErreur("Formats possibles : --xspf, --jspf, --m3u8");
                afficherErreur("Exemple : -d . --m3u8 -o playlist.m3u8");
                return new GestionParametres("-h");

            default:
                afficherErreur("Commande inconnue : " + option);
                afficherErreur("Tapez -h ou --help pour afficher l'aide.");
                return new GestionParametres("-h");
        }
    }


    private boolean estFormat(String s) {
        return "--xspf".equalsIgnoreCase(s)
                || "--jspf".equalsIgnoreCase(s)
                || "--m3u8".equalsIgnoreCase(s);
    }
}
