package ihm;

public interface IHM {
	
	void afficherResultat(String message);

    void afficherErreur(String message);

}
