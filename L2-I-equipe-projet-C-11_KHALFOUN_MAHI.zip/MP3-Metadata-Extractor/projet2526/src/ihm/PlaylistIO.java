package ihm;

import gestionnaireFichiers.FichierMp3;
import playlist.Playlist;

import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class PlaylistIO {

    /**
     * Charge une playlist M3U8 :
     * - ignore les lignes vides et celles qui commencent par '#'
     * - chaque autre ligne est un chemin de fichier mp3
     */
    public Playlist loadM3U8(File m3u8File) throws Exception {
        if (m3u8File == null || !m3u8File.isFile()) {
            throw new IllegalArgumentException("Fichier playlist invalide.");
        }

        Playlist pl = new Playlist("Playlist importée");

        try (BufferedReader br = Files.newBufferedReader(m3u8File.toPath(), StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;

                // ligne = chemin vers mp3
                File mp3 = new File(line);
                if (mp3.exists() && mp3.isFile()) {
                    pl.ajouterMusique(new FichierMp3(mp3));
                }
            }
        }
        return pl;
    }
}
