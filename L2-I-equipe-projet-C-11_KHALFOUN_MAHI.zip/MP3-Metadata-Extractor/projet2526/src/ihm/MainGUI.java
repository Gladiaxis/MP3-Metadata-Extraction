package ihm;

import javax.swing.*;

public class MainGUI {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Look & Feel système (optionnel)
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}

            GUI frame = new GUI();
            frame.setVisible(true);
        });
    }
}
