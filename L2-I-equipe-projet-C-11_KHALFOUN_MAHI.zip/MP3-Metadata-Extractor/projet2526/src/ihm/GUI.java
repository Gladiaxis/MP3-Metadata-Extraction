package ihm;

import gestionnaireFichiers.FichierMp3;
import gestionnaireFichiers.Repertoires;
import metadonnees.Metadonnees;
import playlist.FormatPlaylist;
import playlist.GestionPlaylist;
import playlist.Playlist;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;


public class GUI extends JFrame {

    // --- Données ---
    private File currentDirectory = null;
    private final DefaultListModel<FichierMp3> libraryModel = new DefaultListModel<>();
    private final DefaultListModel<FichierMp3> playlistModel = new DefaultListModel<>();
    private Playlist currentPlaylist = new Playlist("Playlist GUI");

    // --- UI ---
    private final JList<FichierMp3> libraryList = new JList<>(libraryModel);
    private final JList<FichierMp3> playlistList = new JList<>(playlistModel);

    private final JLabel lblFile = new JLabel("Fichier : ");
    private final JLabel lblTitle = new JLabel("Titre : ");
    private final JLabel lblArtist = new JLabel("Artiste : ");
    private final JLabel lblAlbum = new JLabel("Album : ");
    private final JLabel lblYear = new JLabel("Année : ");
    private final JLabel lblDuration = new JLabel("Durée : ");
    private final JLabel lblCover = new JLabel("Cover : ");
    private final JLabel coverLabel = new JLabel();

    private final GestionPlaylist gestionPlaylist = new GestionPlaylist();
    private final PlaylistIO playlistIO = new PlaylistIO(); // lecture M3U8

    public GUI() {
        super("Projet MP3 - GUI (Swing)");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 650);
        setLocationRelativeTo(null);

        setLayout(new BorderLayout());
        add(buildTopBar(), BorderLayout.NORTH);
        add(buildMainSplit(), BorderLayout.CENTER);
        add(buildBottomBar(), BorderLayout.SOUTH);

        setupRenderers();
        setupListeners();
        refreshPlaylistViewFromObject();
    }

    // ---------------- UI BUILDERS ----------------

    private JComponent buildTopBar() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton btnOpenMp3 = new JButton("Ouvrir MP3...");
        JButton btnExploreDir = new JButton("Explorer dossier...");
        JButton btnDefaultPlaylist = new JButton("Playlist par défaut (dossier)");
        JButton btnClearPlaylist = new JButton("Vider playlist");

        btnOpenMp3.addActionListener(e -> chooseAndShowMp3Metadata());
        btnExploreDir.addActionListener(e -> chooseAndExploreDirectory());
        btnDefaultPlaylist.addActionListener(e -> buildDefaultPlaylistFromCurrentDir());
        btnClearPlaylist.addActionListener(e -> clearPlaylist());

        panel.add(btnOpenMp3);
        panel.add(btnExploreDir);
        panel.add(btnDefaultPlaylist);
        panel.add(btnClearPlaylist);

        return panel;
    }

    private JComponent buildMainSplit() {
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.55);

        // Gauche: bibliothèque + métadonnées
        JPanel left = new JPanel(new BorderLayout(10, 10));
        left.setBorder(new EmptyBorder(10, 10, 10, 10));

        left.add(buildLibraryPanel(), BorderLayout.CENTER);
        left.add(buildMetadataPanel(), BorderLayout.SOUTH);

        // Droite: playlist
        JPanel right = new JPanel(new BorderLayout(10, 10));
        right.setBorder(new EmptyBorder(10, 10, 10, 10));
        right.add(buildPlaylistPanel(), BorderLayout.CENTER);

        split.setLeftComponent(left);
        split.setRightComponent(right);
        return split;
    }

    private JComponent buildLibraryPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));

        JLabel title = new JLabel("Bibliothèque (MP3 du dossier)");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 14f));

        panel.add(title, BorderLayout.NORTH);

        libraryList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scroll = new JScrollPane(libraryList);
        panel.add(scroll, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnAddToPlaylist = new JButton("Ajouter → Playlist");
        JButton btnRemoveFromPlaylist = new JButton("Retirer ← Playlist");
        buttons.add(btnAddToPlaylist);
        buttons.add(btnRemoveFromPlaylist);

        btnAddToPlaylist.addActionListener(e -> addSelectedToPlaylist());
        btnRemoveFromPlaylist.addActionListener(e -> removeSelectedFromPlaylist());

        panel.add(buttons, BorderLayout.SOUTH);
        return panel;
    }

    private JComponent buildMetadataPanel() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        outer.setBorder(BorderFactory.createTitledBorder("Métadonnées"));

        // Zone cover
        coverLabel.setHorizontalAlignment(SwingConstants.CENTER);
        coverLabel.setVerticalAlignment(SwingConstants.CENTER);
        coverLabel.setPreferredSize(new Dimension(180, 180));
        coverLabel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        coverLabel.setText("Aucune cover");

        outer.add(coverLabel, BorderLayout.WEST);

        // Zone texte
        JPanel text = new JPanel(new GridLayout(0, 1, 4, 4));
        text.add(lblFile);
        text.add(lblTitle);
        text.add(lblArtist);
        text.add(lblAlbum);
        text.add(lblYear);
        text.add(lblDuration);
        text.add(lblCover);

        outer.add(text, BorderLayout.CENTER);

        JButton btnSaveMeta = new JButton("Sauvegarder métadonnées (TXT)...");
        btnSaveMeta.addActionListener(e -> saveDisplayedMetadataToTxt());
        outer.add(btnSaveMeta, BorderLayout.SOUTH);

        return outer;
    }


    private JComponent buildPlaylistPanel() {
        JPanel panel = new JPanel(new BorderLayout(8, 8));

        JLabel title = new JLabel("Playlist");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 14f));
        panel.add(title, BorderLayout.NORTH);

        playlistList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scroll = new JScrollPane(playlistList);
        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    private JComponent buildBottomBar() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JButton btnSavePlaylist = new JButton("Enregistrer playlist...");
        JButton btnOpenPlaylist = new JButton("Ouvrir playlist... (M3U8)");
        panel.add(btnSavePlaylist);
        panel.add(btnOpenPlaylist);

        btnSavePlaylist.addActionListener(e -> savePlaylistDialog());
        btnOpenPlaylist.addActionListener(e -> openPlaylistDialog());

        return panel;
    }

    private void setupRenderers() {
        // Afficher nom fichier dans les listes
        libraryList.setCellRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof FichierMp3 mp3) {
                    setText(mp3.getNomFichier());
                }
                return this;
            }
        });

        playlistList.setCellRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof FichierMp3 mp3) {
                    setText(mp3.getNomFichier());
                }
                return this;
            }
        });
    }

    private void setupListeners() {
        // Charger métadonnées uniquement quand on sélectionne 1 mp3 dans la bibliothèque
        libraryList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                FichierMp3 selected = libraryList.getSelectedValue();
                if (selected != null) {
                    showMetadata(selected);
                }
            }
        });
    }

    // ---------------- ACTIONS ----------------

    private void chooseAndExploreDirectory() {
        JFileChooser fc = new JFileChooser();
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fc.setDialogTitle("Choisir un dossier à explorer");
        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);

        int res = fc.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File dir = fc.getSelectedFile();
            exploreDirectory(dir);
        }
    }

    private void exploreDirectory(File dir) {
        currentDirectory = dir;
        libraryModel.clear();

        Repertoires rep = new Repertoires(dir.getAbsolutePath());
        ArrayList<FichierMp3> mp3s = rep.getFichiersMp3();
        for (FichierMp3 mp3 : mp3s) {
            libraryModel.addElement(mp3);
        }

        setTitle("Projet MP3 - GUI (Swing) | Dossier: " + dir.getAbsolutePath());

        if (libraryModel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Aucun MP3 trouvé dans ce dossier.", "Info", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void chooseAndShowMp3Metadata() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Choisir un fichier MP3");
        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);

        int res = fc.showOpenDialog(this);
        if (res == JFileChooser.APPROVE_OPTION) {
            File f = fc.getSelectedFile();
            if (f == null || !f.isFile()) return;

            currentDirectory = f.getParentFile();
            FichierMp3 mp3 = new FichierMp3(f);
            showMetadata(mp3);
        }
    }

    private void showMetadata(FichierMp3 mp3) {
        lblFile.setText("Fichier : " + mp3.getCheminFichier().getAbsolutePath());

        Metadonnees meta = mp3.getMetadonnees();
        if (meta == null) {
            lblTitle.setText("Titre : (erreur lecture)");
            lblArtist.setText("Artiste : ");
            lblAlbum.setText("Album : ");
            lblYear.setText("Année : ");
            lblDuration.setText("Durée : ");
            lblCover.setText("Cover : ");
            JOptionPane.showMessageDialog(this, "Impossible de lire les métadonnées.", "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }


        lblTitle.setText("Titre : " + meta.getTitre());
        lblArtist.setText("Artiste : " + meta.getArtiste());
        lblAlbum.setText("Album : " + meta.getAlbum());
        lblYear.setText("Année : " + meta.getAnnee());
        lblDuration.setText("Durée : " + meta.getDuree());
        lblCover.setText("Cover : " + (meta.containCover() ? "Oui" : "Non"));
        lblCover.setText("Cover : " + (meta.containCover() ? "Oui" : "Non"));

        if (meta.containCover() && meta.getCoverBytes() != null) {
            ImageIcon icon = createThumbnail(meta.getCoverBytes(), 160, 160);
            if (icon != null) {
                coverLabel.setIcon(icon);
                coverLabel.setText(null);
            } else {
                coverLabel.setIcon(null);
                coverLabel.setText("Cover non décodable");
            }
        } else {
            coverLabel.setIcon(null);
            coverLabel.setText("Aucune cover");
        }

        coverLabel.revalidate();
        coverLabel.repaint();




    }

    private void addSelectedToPlaylist() {
        var selected = libraryList.getSelectedValuesList();
        if (selected == null || selected.isEmpty()) return;

        for (FichierMp3 mp3 : selected) {
            currentPlaylist.ajouterMusique(mp3);
        }
        refreshPlaylistViewFromObject();
    }

    private void removeSelectedFromPlaylist() {
        var selected = playlistList.getSelectedValuesList();
        if (selected == null || selected.isEmpty()) return;

        for (FichierMp3 mp3 : selected) {
            currentPlaylist.supprimerMusique(mp3);
        }
        refreshPlaylistViewFromObject();
    }

    private void buildDefaultPlaylistFromCurrentDir() {
        if (currentDirectory == null) {
            JOptionPane.showMessageDialog(this, "Choisis d'abord un dossier (Explorer dossier...).", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Repertoires rep = new Repertoires(currentDirectory.getAbsolutePath());
        currentPlaylist = gestionPlaylist.creerPlaylistParDefaut("Playlist par défaut", rep);
        refreshPlaylistViewFromObject();

        JOptionPane.showMessageDialog(this,
                "Playlist par défaut créée (" + currentPlaylist.getTaille() + " morceaux).",
                "OK", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearPlaylist() {
        currentPlaylist = new Playlist("Playlist GUI");
        refreshPlaylistViewFromObject();
    }

    private void refreshPlaylistViewFromObject() {
        playlistModel.clear();
        for (FichierMp3 mp3 : currentPlaylist.getMorceaux()) {
            playlistModel.addElement(mp3);
        }
    }

    private void savePlaylistDialog() {
        if (currentPlaylist.getTaille() == 0) {
            JOptionPane.showMessageDialog(this, "Playlist vide : rien à enregistrer.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // Choix format
        FormatPlaylist format = (FormatPlaylist) JOptionPane.showInputDialog(
                this,
                "Choisir le format :",
                "Format playlist",
                JOptionPane.QUESTION_MESSAGE,
                null,
                FormatPlaylist.values(),
                FormatPlaylist.M3U8
        );
        if (format == null) return;

        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Enregistrer la playlist");
        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);

        // nom suggéré
        fc.setSelectedFile(new File("playlist." + format.name().toLowerCase()));

        int res = fc.showSaveDialog(this);
        if (res != JFileChooser.APPROVE_OPTION) return;

        File out = fc.getSelectedFile();
        if (out == null) return;

        // Écriture avec ton code existant
        gestionPlaylist.enregistrerDansFichier(currentPlaylist, format, out.getAbsolutePath());
        JOptionPane.showMessageDialog(this, "Playlist enregistrée : " + out.getAbsolutePath(), "OK", JOptionPane.INFORMATION_MESSAGE);
    }

    private void openPlaylistDialog() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Ouvrir une playlist (M3U8)");
        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);

        int res = fc.showOpenDialog(this);
        if (res != JFileChooser.APPROVE_OPTION) return;

        File in = fc.getSelectedFile();
        if (in == null || !in.isFile()) return;

        try {
            Playlist loaded = playlistIO.loadM3U8(in);
            currentPlaylist = loaded;
            refreshPlaylistViewFromObject();
            JOptionPane.showMessageDialog(this, "Playlist chargée (" + currentPlaylist.getTaille() + " morceaux).", "OK", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur ouverture playlist : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveDisplayedMetadataToTxt() {
        String fileLine = lblFile.getText();
        if (fileLine == null || !fileLine.startsWith("Fichier : ")) {
            JOptionPane.showMessageDialog(this, "Aucun fichier sélectionné.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Enregistrer les métadonnées (TXT)");
        if (currentDirectory != null) fc.setCurrentDirectory(currentDirectory);
        fc.setSelectedFile(new File("metadonnees.txt"));

        int res = fc.showSaveDialog(this);
        if (res != JFileChooser.APPROVE_OPTION) return;

        File out = fc.getSelectedFile();
        if (out == null) return;

        // Contenu simple
        String content =
                lblFile.getText() + "\n" +
                        lblTitle.getText() + "\n" +
                        lblArtist.getText() + "\n" +
                        lblAlbum.getText() + "\n" +
                        lblYear.getText() + "\n" +
                        lblDuration.getText() + "\n" +
                        lblCover.getText() + "\n";

        try {
            Files.writeString(out.toPath(), content, StandardCharsets.UTF_8);
            JOptionPane.showMessageDialog(this, "Métadonnées enregistrées : " + out.getAbsolutePath(), "OK", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur écriture : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }
    private ImageIcon createThumbnail(byte[] imageBytes, int maxW, int maxH) {
        try {
            if (imageBytes == null || imageBytes.length == 0) return null;

            ByteArrayInputStream in = new ByteArrayInputStream(imageBytes);
            BufferedImage img = ImageIO.read(in);

            if (img == null) return null; // IMPORTANT

            int w = img.getWidth();
            int h = img.getHeight();
            double scale = Math.min((double) maxW / w, (double) maxH / h);

            int newW = (int) (w * scale);
            int newH = (int) (h * scale);

            Image scaled = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);

        } catch (Exception e) {
            return null;
        }
    }


}
