package gestionnaireFichiers;

import java.io.File;
import java.util.ArrayList;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

 /**La classe répertoire doit permettre à l'utilisateur d'explorer complètement un répertoire et pour afficher l'ensemble
 *  des fichiers mp3.
  *

 *  Elle doit filtrer les fichiers pour ne retenir que les fichiers mp3 de cette arborescence.
 *  Elle vérifiera donc chaque extension et type MIME pour ne retenir que les fichiers mp3.

*/

public class Repertoires {


    private File racine;
    private ArrayList<FichierMp3>fichiersMp3;


    public Repertoires(String cheminRepertoire){
        this.racine = new File(cheminRepertoire);
        this.fichiersMp3=new ArrayList<>();
        System.out.println("\nChemin reçu : " + cheminRepertoire);


        if (!racine.exists() || !racine.isDirectory()) {
            System.err.println("Le chemin fourni n'est pas un répertoire valide : " + cheminRepertoire);
            return;
        }

        // Vérification si le répertoire est vide
        File[] contenus = racine.listFiles();
        if (contenus == null || contenus.length == 0) {
            System.out.println("Le répertoire est vide : " + cheminRepertoire);
            return;
        }

        // Exploration complète
        explorerRepertoire(racine);

        // Vérifier si aucun MP3 trouvé
        if (fichiersMp3.isEmpty()) {
            System.out.println("Aucun fichier MP3 trouvé dans le répertoire.");
        }
    }

     public File getRacine() {
         return racine;
     }


     private void explorerRepertoire(File dossier) {
        File[] contenus = dossier.listFiles();
        if (contenus == null) {
            return; // rien à parcourir (droits insuffisants, etc.)
        }

        for (File f : contenus) {
            if (f.isDirectory()) {
                // récursivité : on explore les sous-dossiers
                explorerRepertoire(f);
            } else if (f.isFile()) {
                // on teste si c'est un mp3
                if (estMp3(f)) {
                    FichierMp3 fichierMp3 = new FichierMp3(f);
                    fichiersMp3.add(fichierMp3);
                }
            }
        }
    }


    private boolean estMp3(File f) {
        String nom = f.getName().toLowerCase();

        // 1) Vérification extension
        if (!nom.endsWith(".mp3")) {
            return false;
        }

        // 2) Vérification type MIME
        try {
            Path p = f.toPath();
            String mime = Files.probeContentType(p);
            if (mime == null) {
                // certains systèmes peuvent retourner null → on accepte avec l'extension seule
                return true;
            }
            // On vérifie que c'est bien un type audio lié au mp3
            return mime.equals("audio/mpeg") || mime.equals("audio/mp3") || mime.startsWith("audio");
        } catch (IOException e) {
            // en cas d'erreur, on se rabat au test sur extension
            return true;
        }
    }

    //Retourne la liste des fichiers mp3 trouvés dans l'arborescence.

    public ArrayList<FichierMp3> getFichiersMp3() {
        return fichiersMp3;
    }




    //Il nous manque le parcours des sous-rep

}
