package gestionnaireFichiers;

import java.io.File;
import metadonnees.Metadonnees;


/**
 * La classe FichierMp3 va nous permettre de récupérer les métadonnées chargées pas Metadonnees.
 */


public class FichierMp3 {


    private File cheminFichier;
    private String nomFichier;
    private Metadonnees metadonnees; // au départ null

    /**
     * @param cheminFichier
     */
    public FichierMp3(File cheminFichier) {
        this.cheminFichier = cheminFichier;
        this.nomFichier = cheminFichier.getName();
        this.metadonnees = null;     // on ne lit PAS les métadonnées ici
    }


//----------------------------------------------------------------------------------------------------------------------
    //Getters:

    public File getCheminFichier() {
        return cheminFichier;
    }

    public String getNomFichier() {
        return nomFichier;
    }

                            //-------------------------------------------//
    //Setters :

    public void setNomFichier(String nomFichier) {
        this.nomFichier = nomFichier;
    }
//----------------------------------------------------------------------------------------------------------------------
    //je rajouterais la suite si besoin plus tard si jvois que c nécessaire.



    /**
     * Charge les métadonnées uniquement à la demande.
     */
    public Metadonnees getMetadonnees() {
        if (metadonnees == null) {
            try {
                metadonnees = new Metadonnees(cheminFichier.getAbsolutePath());
            } catch (Exception e) {
                e.printStackTrace();
                metadonnees = null;
            }
        }
        return metadonnees;
    }

}
