package controleur;

import gestionnaireFichiers.FichierMp3;
import gestionnaireFichiers.Repertoires;
import metadonnees.Metadonnees;
import playlist.GestionPlaylist;
import playlist.Playlist;
import playlist.FormatPlaylist;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * Classe responsable de la gestion et de l'exécution des paramètres
 * passés en ligne de commande dans l'application.
 *
 * <p>
 * Cette classe agit comme un contrôleur CLI (Command Line Interface).
 * Elle interprète les options fournies par l'utilisateur et déclenche
 * l'action correspondante :
 * </p>
 *
 * <ul>
 *     <li>Affichage de l'aide</li>
 *     <li>Extraction des métadonnées d'un fichier MP3</li>
 *     <li>Exploration d'un répertoire</li>
 *     <li>Génération de playlists</li>
 * </ul>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class GestionParametres {

    /**
     * Action principale à exécuter (ex : -h, -f, -d, playlist).
     */
    private String action;

    /**
     * Chemin du fichier MP3 (option -f).
     */
    private String fichier;

    /**
     * Chemin du répertoire à explorer (option -d).
     */
    private String dossier;

    /**
     * Format de la playlist à générer (xspf, jspf, m3u8).
     */
    private String format;

    /**
     * Chemin du fichier de sortie pour la playlist.
     */
    private String sortie;

    // ------------------------------------------------------------------
    // CONSTRUCTEURS
    // ------------------------------------------------------------------

    /**
     * Construit un gestionnaire de paramètres avec une action donnée.
     *
     * @param action action à exécuter (ex : -h, -f, -d, playlist)
     */
    public GestionParametres(String action) {
        this.action = action;
    }

    /**
     * Construit un gestionnaire avec une action et un paramètre associé.
     * Le paramètre est affecté selon le type d'action.
     *
     * @param action option de commande (-f ou -d)
     * @param param  valeur associée à l'option
     */
    public GestionParametres(String action, String param) {
        this(action);
        if ("-d".equals(action)) {
            this.dossier = param;
        } else if ("-f".equals(action)) {
            this.fichier = param;
        } else {
            this.fichier = param;
        }
    }

    /**
     * Construit un gestionnaire pour la génération de playlists.
     *
     * @param action  action principale (playlist)
     * @param dossier répertoire source des fichiers MP3
     * @param format  format de la playlist
     * @param sortie  fichier de sortie
     */
    public GestionParametres(String action, String dossier, String format, String sortie) {
        this(action);
        this.dossier = dossier;
        this.format = format;
        this.sortie = sortie;
    }

    // ------------------------------------------------------------------
    // POINT D’ENTRÉE : exécution de l’action
    // ------------------------------------------------------------------

    /**
     * Exécute l'action demandée en fonction des paramètres fournis.
     *
     * @return message résultant de l'exécution de la commande
     */
    public String execute() {

        switch (action) {

            case "-h":
            case "--help":
                return afficherAide();

            case "-f":
                return extraireMetadonnees(fichier);

            case "-d":
                return explorerRepertoire(dossier);

            case "playlist":
                return genererPlaylist(dossier, format, sortie);

            default:
                return "Erreur : commande inconnue.";
        }
    }

    // ------------------------------------------------------------------
    // AIDE
    // ------------------------------------------------------------------

    /**
     * Retourne le message d'aide décrivant l'ensemble des commandes
     * disponibles dans l'application.
     *
     * @return texte d'aide à afficher dans la console
     */
    public String afficherAide() {
        return """
               Commandes disponibles :

               -h | --help
                   Affiche cette aide.

               -f "fichier.mp3"
                   Extrait et affiche les métadonnées du fichier MP3.

               -d <répertoire>
                   Liste tous les fichiers MP3 présents dans le répertoire.

               -d <répertoire> --<format> -o <fichier.sortie>
                   Génère une playlist à partir du répertoire.
                   Formats possibles : --xspf, --jspf, --m3u8

               Exemples :
                   -f "titre.mp3"
                   -d .
                   -d . --m3u8 -o ./nvlPlaylist.m3u8
               """;
    }

    // ------------------------------------------------------------------
    // 1) METADATA : -f <fichier.mp3>
    // ------------------------------------------------------------------

    /**
     * Extrait et affiche les métadonnées d'un fichier MP3.
     *
     * @param cheminFichier chemin du fichier MP3
     * @return métadonnées formatées ou message d'erreur
     */
    private String extraireMetadonnees(String cheminFichier) {

        if (cheminFichier == null) {
            return "Erreur : aucun fichier spécifié.";
        }

        File f = new File(cheminFichier);
        if (!f.exists() || !f.isFile()) {
            return "Erreur : le fichier n'existe pas : " + cheminFichier;
        }

        FichierMp3 mp3 = new FichierMp3(f);
        Metadonnees meta = mp3.getMetadonnees();

        if (meta == null) {
            return "Impossible de lire les métadonnées pour : " + cheminFichier;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Fichier : ").append(f.getAbsolutePath()).append("\n");
        sb.append("Titre   : ").append(meta.getTitre()).append("\n");
        sb.append("Artiste : ").append(meta.getArtiste()).append("\n");
        sb.append("Album   : ").append(meta.getAlbum()).append("\n");
        sb.append("Année   : ").append(meta.getAnnee()).append("\n");
        sb.append("Durée   : ").append(meta.getDuree()).append("\n");
        sb.append("Pochette: ").append(meta.containCover() ? "oui" : "non").append("\n");

        return sb.toString();
    }

    // ------------------------------------------------------------------
    // 2) EXPLORER : -d <répertoire>
    // ------------------------------------------------------------------

    /**
     * Explore un répertoire et liste les fichiers MP3 qu'il contient.
     *
     * @param cheminDossier chemin du répertoire à explorer
     * @return liste formatée des fichiers MP3 ou message d'erreur
     */
    private String explorerRepertoire(String cheminDossier) {

        if (cheminDossier == null) {
            return "Erreur : aucun répertoire spécifié.";
        }

        Repertoires rep = new Repertoires(cheminDossier);
        List<FichierMp3> fichiers = rep.getFichiersMp3();

        if (fichiers.isEmpty()) {
            return "Aucun fichier MP3 trouvé dans : " + cheminDossier;
        }

        StringBuilder sb = new StringBuilder("Fichiers MP3 trouvés dans ");
        sb.append(cheminDossier).append(" :\n");

        for (FichierMp3 f : fichiers) {
            sb.append("- ").append(f.getNomFichier()).append("\n");
        }

        return sb.toString();
    }

    // ------------------------------------------------------------------
    // 3) PLAYLIST : -d <dossier> --<format> -o <sortie>
    // ------------------------------------------------------------------

    /**
     * Génère une playlist à partir d'un répertoire contenant des fichiers MP3.
     *
     * @param cheminDossier répertoire source
     * @param formatStr     format de la playlist (xspf, jspf, m3u8)
     * @param fichierSortie chemin du fichier de sortie
     * @return message indiquant le succès ou l'échec de l'opération
     */
    private String genererPlaylist(String cheminDossier, String formatStr, String fichierSortie) {

        if (cheminDossier == null) {
            return "Erreur : aucun répertoire spécifié.";
        }
        if (formatStr == null) {
            return "Erreur : aucun format de playlist spécifié (xspf, jspf, m3u8).";
        }
        if (fichierSortie == null) {
            return "Erreur : aucun fichier de sortie spécifié.";
        }

        Repertoires rep = new Repertoires(cheminDossier);
        GestionPlaylist gp = new GestionPlaylist();
        Playlist playlist = gp.creerPlaylistParDefaut("Playlist CLI", rep);

        if (playlist.getTaille() == 0) {
            return "Impossible de créer une playlist : aucun MP3 trouvé dans " + cheminDossier;
        }

        FormatPlaylist formatEnum;
        try {
            formatEnum = FormatPlaylist.valueOf(formatStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            return "Format de playlist inconnu : " + formatStr
                    + ". Formats possibles : xspf, jspf, m3u8.";
        }

        String contenu = gp.exporterPlaylist(playlist, formatEnum);

        try {
            Path out = Paths.get(fichierSortie);
            Files.write(out, contenu.getBytes(StandardCharsets.UTF_8));
            return "Playlist générée avec succès : "
                    + out.toAbsolutePath() + " (format " + formatEnum + ").";
        } catch (IOException e) {
            return "Erreur lors de l'écriture de la playlist dans '" + fichierSortie
                    + "' : " + e.getMessage();
        }
    }
}
