package playlist;

import java.util.ArrayList;

import gestionnaireFichiers.Repertoires;
import gestionnaireFichiers.FichierMp3;
import metadonnees.Metadonnees;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;

/**
 * Classe responsable de la gestion et de l’export des playlists.
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe centralise toute la logique liée aux playlists :
 * </p>
 * <ul>
 *   <li>création de playlists à partir d’un répertoire de fichiers MP3,</li>
 *   <li>export de playlists dans différents formats standards,</li>
 *   <li>écriture des playlists dans des fichiers.</li>
 * </ul>
 *
 * <h2>Formats supportés</h2>
 * <p>
 * Les formats de sortie sont définis par l’énumération {@link FormatPlaylist} :
 * </p>
 * <ul>
 *   <li>M3U8 (texte UTF-8),</li>
 *   <li>XSPF (XML Shareable Playlist Format),</li>
 *   <li>JSPF (JSON Shareable Playlist Format).</li>
 * </ul>
 *
 * <h2>Architecture</h2>
 * <p>
 * Cette classe fait le lien entre :
 * </p>
 * <ul>
 *   <li>la couche fichier ({@link Repertoires}, {@link FichierMp3}),</li>
 *   <li>la couche métier playlist ({@link Playlist}),</li>
 *   <li>les interfaces utilisateur (CLI et GUI).</li>
 * </ul>
 *
 * <p>
 * Elle ne gère aucune interaction directe avec l’utilisateur :
 * elle fournit uniquement des services métier.
 * </p>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class GestionPlaylist {

    // -------------------------------------------------------------------------
    // CRÉATION DE PLAYLIST
    // -------------------------------------------------------------------------

    /**
     * Crée une playlist par défaut à partir d’un répertoire.
     *
     * <p>
     * Tous les fichiers MP3 trouvés dans l’objet {@link Repertoires}
     * sont ajoutés à la playlist, dans l’ordre fourni par celui-ci.
     * </p>
     *
     * @param nom nom de la playlist à créer
     * @param rep répertoire déjà exploré contenant les fichiers MP3
     * @return une {@link Playlist} contenant tous les morceaux du répertoire
     */
    public Playlist creerPlaylistParDefaut(String nom, Repertoires rep) {

        Playlist playlist = new Playlist(nom);
        ArrayList<FichierMp3> fichiers = rep.getFichiersMp3();

        for (FichierMp3 f : fichiers) {
            playlist.ajouterMusique(f);
        }

        return playlist;
    }

    // -------------------------------------------------------------------------
    // EXPORT DE PLAYLIST (FORMAT GÉNÉRIQUE)
    // -------------------------------------------------------------------------

    /**
     * Exporte une playlist dans le format demandé.
     *
     * <p>
     * Cette méthode agit comme un point d’entrée unique pour l’export
     * et délègue la génération du contenu à la méthode spécialisée
     * correspondant au format choisi.
     * </p>
     *
     * @param playlist playlist à exporter
     * @param format format de sortie souhaité
     * @return représentation textuelle de la playlist dans le format demandé
     * @throws IllegalArgumentException si le format n’est pas supporté
     */
    public String exporterPlaylist(Playlist playlist, FormatPlaylist format) {

        switch (format) {
            case M3U8:
                return exporterM3U8(playlist);
            case XSPF:
                return exporterXSPF(playlist);
            case JSPF:
                return exporterJSPF(playlist);
            default:
                // Cas théoriquement impossible grâce à l'énumération
                throw new IllegalArgumentException(
                        "Format de playlist non supporté : " + format
                );
        }
    }

    // -------------------------------------------------------------------------
    // EXPORT M3U8
    // -------------------------------------------------------------------------

    /**
     * Génère le contenu d’une playlist au format M3U8.
     *
     * <p>
     * Le format M3U8 est un format texte simple :
     * </p>
     * <ul>
     *   <li>une ligne d’en-tête {@code #EXTM3U},</li>
     *   <li>une ligne par fichier MP3 contenant son chemin absolu.</li>
     * </ul>
     *
     * @param playlist playlist à exporter
     * @return contenu texte au format M3U8
     */
    private String exporterM3U8(Playlist playlist) {

        StringBuilder sb = new StringBuilder();
        sb.append("#EXTM3U\n");

        for (FichierMp3 f : playlist.getMorceaux()) {
            sb.append(f.getCheminFichier().getAbsolutePath()).append("\n");
        }

        return sb.toString();
    }

    // -------------------------------------------------------------------------
    // EXPORT XSPF (XML)
    // -------------------------------------------------------------------------

    /**
     * Génère le contenu d’une playlist au format XSPF (XML).
     *
     * <p>
     * Le format XSPF permet d’inclure des métadonnées enrichies
     * telles que le titre, l’artiste et l’album.
     * </p>
     *
     * @param playlist playlist à exporter
     * @return contenu XML XSPF
     */
    private String exporterXSPF(Playlist playlist) {

        StringBuilder sb = new StringBuilder();

        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        sb.append("<playlist version=\"1\" xmlns=\"http://xspf.org/ns/0/\">\n");
        sb.append("  <title>")
          .append(echapperXml(playlist.getNom()))
          .append("</title>\n");
        sb.append("  <trackList>\n");

        for (FichierMp3 f : playlist.getMorceaux()) {

            String chemin = f.getCheminFichier().getAbsolutePath();
            String uri = "file:///" + chemin.replace("\\", "/");
            Metadonnees meta = f.getMetadonnees();

            sb.append("    <track>\n");
            sb.append("      <location>")
              .append(echapperXml(uri))
              .append("</location>\n");

            if (meta != null) {

                if (!meta.getTitre().isEmpty()) {
                    sb.append("      <title>")
                      .append(echapperXml(meta.getTitre()))
                      .append("</title>\n");
                }

                if (!meta.getArtiste().isEmpty()) {
                    sb.append("      <creator>")
                      .append(echapperXml(meta.getArtiste()))
                      .append("</creator>\n");
                }

                if (!meta.getAlbum().isEmpty()) {
                    sb.append("      <album>")
                      .append(echapperXml(meta.getAlbum()))
                      .append("</album>\n");
                }
            }

            sb.append("    </track>\n");
        }

        sb.append("  </trackList>\n");
        sb.append("</playlist>\n");

        return sb.toString();
    }

    // -------------------------------------------------------------------------
    // EXPORT JSPF (JSON)
    // -------------------------------------------------------------------------

    /**
     * Génère le contenu d’une playlist au format JSPF (JSON).
     *
     * <p>
     * Le format JSPF est une représentation JSON de la playlist,
     * adaptée aux applications web et aux traitements JavaScript.
     * </p>
     *
     * @param playlist playlist à exporter
     * @return contenu JSON JSPF
     */
    private String exporterJSPF(Playlist playlist) {

        StringBuilder sb = new StringBuilder();

        sb.append("{\n");
        sb.append("  \"playlist\": {\n");
        sb.append("    \"title\": \"")
          .append(echapperJson(playlist.getNom()))
          .append("\",\n");
        sb.append("    \"track\": [\n");

        ArrayList<FichierMp3> morceaux = playlist.getMorceaux();

        for (int i = 0; i < morceaux.size(); i++) {

            FichierMp3 f = morceaux.get(i);
            String chemin = f.getCheminFichier().getAbsolutePath();
            String uri = "file:///" + chemin.replace("\\", "/");
            Metadonnees meta = f.getMetadonnees();

            sb.append("      {\n");
            sb.append("        \"location\": \"")
              .append(echapperJson(uri))
              .append("\"");

            if (meta != null) {

                if (!meta.getTitre().isEmpty()) {
                    sb.append(",\n        \"title\": \"")
                      .append(echapperJson(meta.getTitre()))
                      .append("\"");
                }

                if (!meta.getArtiste().isEmpty()) {
                    sb.append(",\n        \"creator\": \"")
                      .append(echapperJson(meta.getArtiste()))
                      .append("\"");
                }

                if (!meta.getAlbum().isEmpty()) {
                    sb.append(",\n        \"album\": \"")
                      .append(echapperJson(meta.getAlbum()))
                      .append("\"");
                }
            }

            sb.append("\n      }");
            if (i < morceaux.size() - 1) {
                sb.append(",");
            }
            sb.append("\n");
        }

        sb.append("    ]\n");
        sb.append("  }\n");
        sb.append("}\n");

        return sb.toString();
    }

    // -------------------------------------------------------------------------
    // MÉTHODES UTILITAIRES
    // -------------------------------------------------------------------------

    /**
     * Échappe les caractères spéciaux pour une insertion XML valide.
     *
     * @param s chaîne à échapper
     * @return chaîne XML-safe
     */
    private String echapperXml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    /**
     * Échappe les caractères spéciaux pour une insertion JSON valide.
     *
     * @param s chaîne à échapper
     * @return chaîne JSON-safe
     */
    private String echapperJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // -------------------------------------------------------------------------
    // ÉCRITURE DANS UN FICHIER
    // -------------------------------------------------------------------------

    /**
     * Exporte une playlist directement dans un fichier.
     *
     * <p>
     * Le fichier est écrit en UTF-8 et écrasé s’il existe déjà.
     * </p>
     *
     * @param playlist playlist à exporter
     * @param format format de sortie
     * @param cheminFichier chemin du fichier cible
     */
    public void enregistrerDansFichier(
            Playlist playlist,
            FormatPlaylist format,
            String cheminFichier) {

        try {
            String contenu = exporterPlaylist(playlist, format);
            Path path = Paths.get(cheminFichier);
            Files.write(path, contenu.getBytes(StandardCharsets.UTF_8));
            System.out.println("Playlist enregistrée dans : " + path.toAbsolutePath());
        } catch (Exception e) {
            System.err.println(
                    "Erreur lors de l'écriture de la playlist dans le fichier : "
                    + cheminFichier
            );
            e.printStackTrace();
        }
    }
}
