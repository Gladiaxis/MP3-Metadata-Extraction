package playlist;

/**
 * Énumération des formats de playlists supportés par l'application.
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette énumération définit l'ensemble des formats de playlists
 * que l'application est capable de générer ou de manipuler.
 * </p>
 *
 * <p>
 * Elle est utilisée comme un type sûr (type-safe) afin d'éviter
 * l'utilisation de chaînes de caractères arbitraires pour représenter
 * les formats de sortie.
 * </p>
 *
 * <h2>Formats pris en charge</h2>
 * <ul>
 *   <li>{@link #XSPF} : format XML standardisé (XML Shareable Playlist Format)</li>
 *   <li>{@link #JSPF} : format JSON (JSON Shareable Playlist Format)</li>
 *   <li>{@link #M3U8} : format texte UTF-8 largement utilisé</li>
 * </ul>
 *
 * <h2>Intégration dans le projet</h2>
 * <p>
 * Cette énumération est utilisée notamment par :
 * </p>
 * <ul>
 *   <li>{@code CLI} pour interpréter les options utilisateur</li>
 *   <li>{@code GUI} pour proposer le choix du format lors de l'export</li>
 *   <li>{@code GestionPlaylist} pour sérialiser les playlists</li>
 * </ul>
 *
 * <h2>Avantages de l'utilisation d'une énumération</h2>
 * <ul>
 *   <li>prévention des erreurs de saisie</li>
 *   <li>meilleure lisibilité du code</li>
 *   <li>facilité d'évolution (ajout futur de formats)</li>
 * </ul>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public enum FormatPlaylist {

    /**
     * XML Shareable Playlist Format (XSPF).
     *
     * <p>
     * Format de playlist basé sur XML, lisible par de nombreux lecteurs
     * multimédias et facilement extensible.
     * </p>
     */
    XSPF,

    /**
     * JSON Shareable Playlist Format (JSPF).
     *
     * <p>
     * Format de playlist basé sur JSON, souvent utilisé dans des
     * contextes web ou des applications modernes.
     * </p>
     */
    JSPF,

    /**
     * M3U8 (UTF-8).
     *
     * <p>
     * Format de playlist texte encodé en UTF-8, largement supporté
     * par les lecteurs audio et vidéo.
     * </p>
     */
    M3U8
}
