package metadonnees;

import java.io.IOException;

// -----------------------------------------------------------------------------
// IMPORTS LIBRAIRIE EXTERNE MP3AGIC
// -----------------------------------------------------------------------------
import com.mpatric.mp3agic.Mp3File;
import com.mpatric.mp3agic.ID3v1;
import com.mpatric.mp3agic.ID3v2;
import com.mpatric.mp3agic.InvalidDataException;
import com.mpatric.mp3agic.UnsupportedTagException;

/**
 * Représente les métadonnées d’un fichier audio MP3.
 *
 * <h2>Choix technologique</h2>
 * <p>
 * Cette classe repose actuellement sur la bibliothèque externe
 * <strong>mp3agic</strong> pour la lecture des tags ID3.
 * </p>
 *
 * <p>
 * Le projet est conçu de manière à pouvoir évoluer vers une autre
 * bibliothèque (par exemple <em>jaudiotagger</em>) sans modifier
 * l’interface publique de cette classe.
 * </p>
 *
 * <h2>Responsabilités</h2>
 * <ul>
 *   <li>charger les métadonnées depuis un fichier MP3</li>
 *   <li>extraire les informations principales (titre, artiste, album, année…)</li>
 *   <li>calculer et formater la durée du fichier</li>
 *   <li>déterminer la présence d’une pochette (cover)</li>
 * </ul>
 *
 * <h2>Stratégie d’extraction</h2>
 * <ol>
 *   <li>priorité aux tags ID3v2 (plus complets)</li>
 *   <li>complément avec ID3v1 si nécessaire</li>
 *   <li>remplacement des valeurs {@code null} par des chaînes vides</li>
 * </ol>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class Metadonnees {

    // -------------------------------------------------------------------------
    // ATTRIBUTS
    // -------------------------------------------------------------------------

    /** Titre du morceau. */
    private String titre;

    /** Nom de l’artiste. */
    private String artiste;

    /** Nom de l’album. */
    private String album;

    /** Année de publication. */
    private String annee;

    /** Commentaire associé au fichier MP3. */
    private String commentaire;

    /**
     * Durée formatée du morceau (format {@code mm:ss}).
     */
    private String duree;

    /**
     * Indique si une pochette (cover) est associée au fichier.
     */
    private boolean hasCover;

    /**
     * Données binaires de la pochette (si présente).
     */
    private byte[] coverBytes;

    // -------------------------------------------------------------------------
    // CONSTRUCTEUR
    // -------------------------------------------------------------------------

    /**
     * Construit un objet {@code Metadonnees} à partir d’un fichier MP3.
     *
     * <p>
     * Le constructeur :
     * </p>
     * <ul>
     *   <li>charge le fichier MP3 via {@link Mp3File}</li>
     *   <li>calcule la durée totale du morceau</li>
     *   <li>extrait les tags ID3v2 si disponibles</li>
     *   <li>complète avec ID3v1 si nécessaire</li>
     * </ul>
     *
     * @param cheminFichier chemin du fichier MP3 à analyser
     * @throws IOException en cas d’erreur d’accès au fichier
     * @throws UnsupportedTagException si le format de tag est incompatible
     * @throws InvalidDataException si les données du fichier sont corrompues
     */
    public Metadonnees(String cheminFichier)
            throws IOException, UnsupportedTagException, InvalidDataException {

        Mp3File mp3 = new Mp3File(cheminFichier);

        // Calcul de la durée
        long dureeSec = mp3.getLengthInSeconds();
        long minutes = dureeSec / 60;
        long secondes = dureeSec % 60;
        this.duree = String.format("%02d:%02d", minutes, secondes);

        String t = null;
        String a = null;
        String al = null;
        String y = null;
        String c = null;

        // Extraction ID3v2
        if (mp3.hasId3v2Tag()) {
            ID3v2 id3v2Tag = mp3.getId3v2Tag();
            t = id3v2Tag.getTitle();
            a = id3v2Tag.getArtist();
            al = id3v2Tag.getAlbum();
            y = id3v2Tag.getYear();
            c = id3v2Tag.getComment();

            byte[] coverData = id3v2Tag.getAlbumImage();
            this.hasCover = (coverData != null && coverData.length > 0);
        } else {
            this.hasCover = false;
        }

        // Complément ID3v1
        if (mp3.hasId3v1Tag()) {
            ID3v1 id3v1Tag = mp3.getId3v1Tag();

            if (t == null || t.isEmpty())   t = id3v1Tag.getTitle();
            if (a == null || a.isEmpty())   a = id3v1Tag.getArtist();
            if (al == null || al.isEmpty()) al = id3v1Tag.getAlbum();
            if (y == null || y.isEmpty())   y = id3v1Tag.getYear();
            if (c == null || c.isEmpty())   c = id3v1Tag.getComment();
        }

        // Normalisation (jamais de null)
        this.titre       = (t != null) ? t : "";
        this.artiste     = (a != null) ? a : "";
        this.album       = (al != null) ? al : "";
        this.annee       = (y != null) ? y : "";
        this.commentaire = (c != null) ? c : "";
    }

    // -------------------------------------------------------------------------
    // GETTERS
    // -------------------------------------------------------------------------

    public String getTitre()       { return titre; }
    public String getArtiste()     { return artiste; }
    public String getAlbum()       { return album; }
    public String getAnnee()       { return annee; }
    public String getCommentaire(){ return commentaire; }
    public String getDuree()       { return duree; }
    public boolean containCover()  { return hasCover; }
    public byte[] getCoverBytes()  { return coverBytes; }

    // -------------------------------------------------------------------------
    // SETTERS
    // -------------------------------------------------------------------------

    public void setTitre(String titre)             { this.titre = titre; }
    public void setArtiste(String artiste)         { this.titre = artiste; }
    public void setAlbum(String album)             { this.titre = album; }
    public void setAnnee(String annee)             { this.titre = annee; }
    public void setCommentaire(String commentaire) { this.titre = commentaire; }

    // -------------------------------------------------------------------------
    // AFFICHAGE
    // -------------------------------------------------------------------------

    /**
     * Retourne une représentation textuelle des métadonnées.
     *
     * @return chaîne formatée des informations principales
     */
    @Override
    public String toString() {
        String coverMsg = hasCover ? "Oui" : "Non";
        return "Titre   : " + titre + "\n"
                + "Artiste : " + artiste + "\n"
                + "Album   : " + album + "\n"
                + "Année   : " + annee + "\n"
                + "Durée   : " + duree + "\n"
                + "Cover   : " + coverMsg;
    }
}
