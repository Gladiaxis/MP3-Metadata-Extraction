package gestionnaireFichiers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

/**
 * Permet l'exploration récursive d'un répertoire afin d'identifier
 * l'ensemble des fichiers audio MP3 qu'il contient.
 *
 * <p>
 * Cette classe parcourt l'intégralité de l'arborescence d'un répertoire
 * racine fourni par l'utilisateur et filtre les fichiers pour ne conserver
 * que ceux correspondant à des fichiers MP3 valides.
 * </p>
 *
 * <p>
 * La détection des fichiers MP3 repose sur deux critères :
 * </p>
 * <ul>
 *     <li>l'extension du fichier (.mp3)</li>
 *     <li>le type MIME détecté par le système</li>
 * </ul>
 *
 * <p>
 * Les fichiers MP3 détectés sont encapsulés dans des objets
 * {@link FichierMp3} et stockés dans une collection interne.
 * </p>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class Repertoires {

    /**
     * Répertoire racine à partir duquel l'exploration est effectuée.
     */
    private File racine;

    /**
     * Liste des fichiers MP3 trouvés dans l'arborescence.
     */
    private ArrayList<FichierMp3> fichiersMp3;

    // ------------------------------------------------------------------
    // CONSTRUCTEUR
    // ------------------------------------------------------------------

    /**
     * Construit un explorateur de répertoire à partir d'un chemin fourni.
     *
     * <p>
     * L'exploration de l'arborescence est déclenchée automatiquement
     * lors de l'instanciation de l'objet.
     * </p>
     *
     * @param cheminRepertoire chemin du répertoire à explorer
     */
    public Repertoires(String cheminRepertoire) {

        this.racine = new File(cheminRepertoire);
        this.fichiersMp3 = new ArrayList<>();

        if (!racine.exists() || !racine.isDirectory()) {
            System.err.println(
                    "Le chemin fourni n'est pas un répertoire valide : "
                            + cheminRepertoire);
            return;
        }

        File[] contenus = racine.listFiles();
        if (contenus == null || contenus.length == 0) {
            System.out.println(
                    "Le répertoire est vide : " + cheminRepertoire);
            return;
        }

        explorerRepertoire(racine);

        if (fichiersMp3.isEmpty()) {
            System.out.println(
                    "Aucun fichier MP3 trouvé dans le répertoire.");
        }
    }

    // ------------------------------------------------------------------
    // GETTERS
    // ------------------------------------------------------------------

    /**
     * Retourne le répertoire racine exploré.
     *
     * @return répertoire racine
     */
    public File getRacine() {
        return racine;
    }

    /**
     * Retourne la liste des fichiers MP3 trouvés dans l'arborescence.
     *
     * @return liste des fichiers MP3
     */
    public ArrayList<FichierMp3> getFichiersMp3() {
        return fichiersMp3;
    }

    // ------------------------------------------------------------------
    // EXPLORATION
    // ------------------------------------------------------------------

    /**
     * Explore récursivement un répertoire et ses sous-répertoires
     * afin d'identifier les fichiers MP3.
     *
     * @param dossier répertoire à explorer
     */
    private void explorerRepertoire(File dossier) {

        File[] contenus = dossier.listFiles();
        if (contenus == null) {
            return; // droits insuffisants ou erreur d'accès
        }

        for (File f : contenus) {
            if (f.isDirectory()) {
                explorerRepertoire(f);
            } else if (f.isFile()) {
                if (estMp3(f)) {
                    fichiersMp3.add(new FichierMp3(f));
                }
            }
        }
    }

    /**
     * Détermine si un fichier correspond à un fichier MP3 valide.
     *
     * <p>
     * La validation repose sur :
     * </p>
     * <ul>
     *     <li>l'extension du fichier</li>
     *     <li>le type MIME détecté par le système</li>
     * </ul>
     *
     * <p>
     * En cas d'impossibilité de déterminer le type MIME, la validation
     * par extension est conservée.
     * </p>
     *
     * @param f fichier à tester
     * @return {@code true} si le fichier est considéré comme un MP3,
     *         {@code false} sinon
     */
    private boolean estMp3(File f) {

        String nom = f.getName().toLowerCase();

        if (!nom.endsWith(".mp3")) {
            return false;
        }

        try {
            Path p = f.toPath();
            String mime = Files.probeContentType(p);

            if (mime == null) {
                return true;
            }

            return mime.equals("audio/mpeg")
                    || mime.equals("audio/mp3")
                    || mime.startsWith("audio");

        } catch (IOException e) {
            return true;
        }
    }
}
