package ihm;

import controleur.GestionParametres;

/**
 * Implémentation de l'interface {@link IHM} pour une utilisation
 * en ligne de commande (CLI – Command Line Interface).
 *
 * <p>
 * Cette classe est responsable :
 * </p>
 * <ul>
 *     <li>de l'analyse des arguments passés au programme</li>
 *     <li>de la création de l'objet {@link GestionParametres} adapté</li>
 *     <li>de l'exécution de l'action demandée</li>
 *     <li>de l'affichage du résultat ou des erreurs</li>
 * </ul>
 *
 * <p>
 * Commandes supportées :
 * </p>
 * <pre>
 *  -h | --help
 *  -f &lt;fichier.mp3&gt;
 *  -d &lt;répertoire&gt;
 *  -d &lt;répertoire&gt; --&lt;format&gt; -o &lt;sortie&gt;
 *      formats : --xspf, --jspf, --m3u8
 * </pre>
 *
 * <p>
 * Exemples d'utilisation :
 * </p>
 * <pre>
 *  java -jar cli.jar -h
 *  java -jar cli.jar -f "musiques/09 Tu sais pas.mp3"
 *  java -jar cli.jar -d .
 *  java -jar cli.jar -d . --m3u8 -o playlist.m3u8
 * </pre>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class CLI implements IHM {

    /**
     * Construit une interface en ligne de commande.
     */
    public CLI() {
    }

    /**
     * Lance l'exécution de l'interface CLI à partir des arguments
     * fournis par l'utilisateur.
     *
     * @param args arguments de la ligne de commande
     */
    public void run(String[] args) {

        GestionParametres gestion = analyserArguments(args);

        String resultat = gestion.execute();

        afficherResultat(resultat);
    }

    // ------------------------------------------------------------------
    // Implémentation de l'interface IHM
    // ------------------------------------------------------------------

    /**
     * Affiche un message de résultat sur la sortie standard.
     *
     * @param message message à afficher
     */
    @Override
    public void afficherResultat(String message) {
        System.out.println(message);
    }

    /**
     * Affiche un message d'erreur sur la sortie d'erreur standard.
     *
     * @param message message d'erreur
     */
    @Override
    public void afficherErreur(String message) {
        System.err.println(message);
    }

    // ------------------------------------------------------------------
    // Analyse des arguments utilisateur
    // ------------------------------------------------------------------

    /**
     * Analyse les arguments fournis par l'utilisateur et construit
     * l'objet {@link GestionParametres} correspondant.
     *
     * <p>
     * En cas d'erreur de syntaxe ou de commande inconnue,
     * l'aide est automatiquement affichée.
     * </p>
     *
     * @param args arguments de la ligne de commande
     * @return instance de {@link GestionParametres} configurée
     */
    private GestionParametres analyserArguments(String[] args) {

        if (args == null || args.length == 0) {
            return new GestionParametres("-h");
        }

        String option = args[0];

        switch (option) {

            case "-h":
            case "--help":
                return new GestionParametres("-h");

            case "-f":
                if (args.length != 2) {
                    afficherErreur("Usage : -f \"fichier.mp3\"");
                    return new GestionParametres("-h");
                }
                return new GestionParametres("-f", args[1]);

            case "-d":

                if (args.length == 2) {
                    return new GestionParametres("-d", args[1]);
                }

                if (args.length == 5
                        && args[3].equals("-o")
                        && estFormat(args[2])) {

                    String format = args[2].substring(2);
                    String dossier = args[1];
                    String sortie = args[4];

                    return new GestionParametres(
                            "playlist", dossier, format, sortie);
                }

                afficherErreur("Usage : -d <dossier> OU -d <dossier> --<format> -o <sortie>");
                afficherErreur("Formats possibles : --xspf, --jspf, --m3u8");
                afficherErreur("Exemple : -d . --m3u8 -o playlist.m3u8");
                return new GestionParametres("-h");

            default:
                afficherErreur("Commande inconnue : " + option);
                afficherErreur("Tapez -h ou --help pour afficher l'aide.");
                return new GestionParametres("-h");
        }
    }

    /**
     * Vérifie si une chaîne correspond à un format de playlist valide.
     *
     * @param s chaîne à tester
     * @return {@code true} si le format est reconnu, {@code false} sinon
     */
    private boolean estFormat(String s) {
        return "--xspf".equalsIgnoreCase(s)
                || "--jspf".equalsIgnoreCase(s)
                || "--m3u8".equalsIgnoreCase(s);
    }
}
