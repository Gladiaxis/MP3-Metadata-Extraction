package ihm;

import gestionnaireFichiers.FichierMp3;
import playlist.Playlist;

import java.io.BufferedReader;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * Classe utilitaire responsable de l'import de playlists depuis un fichier.
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe permet de charger une playlist audio depuis un fichier
 * au format <strong>M3U8</strong> (playlist texte encodée en UTF-8).
 * </p>
 *
 * <h2>Format M3U8 pris en charge</h2>
 * <p>
 * Le format M3U8 est un format de playlist texte dans lequel :
 * </p>
 * <ul>
 *   <li>les lignes commençant par {@code #} sont des commentaires,</li>
 *   <li>les lignes vides sont ignorées,</li>
 *   <li>chaque autre ligne représente le chemin d'un fichier MP3.</li>
 * </ul>
 *
 * <p>
 * Exemple de contenu valide :
 * </p>
 * <pre>
 * #EXTM3U
 * /home/user/Music/titre1.mp3
 * /home/user/Music/titre2.mp3
 * </pre>
 *
 * <h2>Intégration dans le projet</h2>
 * <p>
 * Cette classe est utilisée par :
 * </p>
 * <ul>
 *   <li>{@link GUI} pour l'import de playlists via l'interface graphique</li>
 * </ul>
 *
 * <p>
 * Chaque chemin valide est encapsulé dans un objet {@link FichierMp3}
 * puis ajouté à une {@link Playlist}.
 * </p>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class PlaylistIO {

    /**
     * Charge une playlist depuis un fichier M3U8.
     *
     * <p>
     * Le chargement respecte les règles suivantes :
     * </p>
     * <ul>
     *   <li>les lignes vides sont ignorées,</li>
     *   <li>les lignes commençant par {@code #} sont ignorées,</li>
     *   <li>les autres lignes sont interprétées comme des chemins de fichiers MP3,</li>
     *   <li>seuls les fichiers existants et valides sont ajoutés à la playlist.</li>
     * </ul>
     *
     * <p>
     * Les fichiers MP3 valides sont encapsulés dans des objets
     * {@link FichierMp3} avant d'être ajoutés à la playlist.
     * </p>
     *
     * @param m3u8File fichier M3U8 à charger
     * @return playlist construite à partir du fichier
     * @throws IllegalArgumentException si le fichier est {@code null} ou invalide
     * @throws Exception en cas d'erreur de lecture du fichier
     */
    public Playlist loadM3U8(File m3u8File) throws Exception {

        if (m3u8File == null || !m3u8File.isFile()) {
            throw new IllegalArgumentException("Fichier playlist invalide.");
        }

        Playlist pl = new Playlist("Playlist importée");

        try (BufferedReader br = Files.newBufferedReader(
                m3u8File.toPath(), StandardCharsets.UTF_8)) {

            String line;
            while ((line = br.readLine()) != null) {

                line = line.trim();

                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }

                File mp3 = new File(line);
                if (mp3.exists() && mp3.isFile()) {
                    pl.ajouterMusique(new FichierMp3(mp3));
                }
            }
        }

        return pl;
    }
}
