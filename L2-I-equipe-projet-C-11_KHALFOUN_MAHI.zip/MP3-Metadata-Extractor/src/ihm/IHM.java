package ihm;

/**
 * Interface représentant une Interface Homme-Machine (IHM) de l'application.
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette interface définit un contrat commun pour les différents modes
 * d'interaction avec l'utilisateur.
 * </p>
 *
 * <p>
 * Dans le projet, elle permet d'unifier le comportement des interfaces :
 * </p>
 * <ul>
 *   <li>interface en ligne de commande (CLI)</li>
 *   <li>interface graphique (GUI)</li>
 * </ul>
 *
 * <h2>Principe</h2>
 * <p>
 * Toute classe implémentant {@code IHM} doit être capable :
 * </p>
 * <ul>
 *   <li>d'afficher un message de résultat à l'utilisateur</li>
 *   <li>d'afficher un message d'erreur de manière appropriée</li>
 * </ul>
 *
 * <p>
 * Ce mécanisme favorise :
 * </p>
 * <ul>
 *   <li>la séparation entre la logique métier et l'affichage</li>
 *   <li>la réutilisabilité du code</li>
 *   <li>la cohérence du comportement entre les différents types d'IHM</li>
 * </ul>
 *
 * <h2>Exemples d'implémentation</h2>
 * <ul>
 *   <li>{@link CLI} : affichage via la console standard</li>
 *   <li>{@link GUI} : affichage via des composants Swing</li>
 * </ul>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public interface IHM {

    /**
     * Affiche un message de résultat à destination de l'utilisateur.
     *
     * <p>
     * Cette méthode est utilisée pour afficher :
     * </p>
     * <ul>
     *   <li>le résultat normal d'une commande</li>
     *   <li>un message informatif</li>
     *   <li>une confirmation de succès</li>
     * </ul>
     *
     * @param message message à afficher
     */
    void afficherResultat(String message);

    /**
     * Affiche un message d'erreur à destination de l'utilisateur.
     *
     * <p>
     * Cette méthode est utilisée pour signaler :
     * </p>
     * <ul>
     *   <li>une erreur de saisie utilisateur</li>
     *   <li>une commande invalide</li>
     *   <li>un problème d'exécution</li>
     * </ul>
     *
     * @param message message d'erreur à afficher
     */
    void afficherErreur(String message);
}
