package ihm;

/**
 * Point d'entrée principal de l'application en mode ligne de commande (CLI).
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe contient la méthode {@code main} nécessaire au lancement
 * de l'application Java en mode console.
 * </p>
 *
 * <p>
 * Elle instancie une {@link CLI} et lui transmet les arguments fournis
 * par l'utilisateur afin qu'ils soient analysés et exécutés.
 * </p>
 *
 * <h2>Utilisation</h2>
 * <p>
 * Pour simplifier l'utilisation, il est recommandé de placer le fichier
 * {@code cli.jar} dans le répertoire contenant les fichiers MP3
 * (par exemple un dossier {@code Music}).
 * </p>
 *
 * <pre>
 * java -jar cli.jar -h
 * java -jar cli.jar -f "titre.mp3"
 * java -jar cli.jar -d .
 * java -jar cli.jar -d . --m3u8 -o playlist.m3u8
 * </pre>
 *
 * <h2>Architecture</h2>
 * <p>
 * Cette classe respecte le principe de séparation des responsabilités :
 * </p>
 * <ul>
 *   <li>{@code MainCLI} : point d'entrée</li>
 *   <li>{@link CLI} : interface utilisateur console</li>
 *   <li>{@code GestionParametres} : logique de traitement des commandes</li>
 * </ul>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class MainCLI {

    /**
     * Méthode principale appelée par la JVM au lancement du programme.
     *
     * <p>
     * Elle crée une instance de {@link CLI} et délègue l'exécution
     * de l'application à celle-ci.
     * </p>
     *
     * @param args arguments de la ligne de commande
     */
    public static void main(String[] args) {
        CLI cli = new CLI();
        cli.run(args);
    }
}
