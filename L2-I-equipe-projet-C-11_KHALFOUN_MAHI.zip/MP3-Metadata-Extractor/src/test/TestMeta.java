package test;

import gestionnaireFichiers.FichierMp3;
import metadonnees.Metadonnees;

import java.io.File;

/**
 * Classe de test permettant de vérifier l’extraction des métadonnées
 * d’un fichier MP3.
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe est utilisée à des fins de test et de validation
 * du fonctionnement des classes {@link FichierMp3} et {@link Metadonnees}.
 * </p>
 *
 * <p>
 * Elle permet de :
 * </p>
 * <ul>
 *   <li>charger un fichier MP3 à partir d’un chemin donné,</li>
 *   <li>extraire ses métadonnées,</li>
 *   <li>afficher ces métadonnées dans la console.</li>
 * </ul>
 *
 * <h2>Contexte d’utilisation</h2>
 * <p>
 * Cette classe n’est pas destinée à être utilisée dans le produit final
 * (CLI ou GUI), mais uniquement :
 * </p>
 * <ul>
 *   <li>pour tester la bibliothèque {@code mp3agic},</li>
 *   <li>pour valider le bon fonctionnement de l’extraction ID3,</li>
 *   <li>lors du développement et du débogage.</li>
 * </ul>
 *
 * <h2>Remarque</h2>
 * <p>
 * Le chemin du fichier MP3 est actuellement codé en dur.
 * Il devra être adapté selon l’environnement de test.
 * </p>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class TestMeta {

    /**
     * Point d’entrée de la classe de test.
     *
     * <p>
     * La méthode :
     * </p>
     * <ol>
     *   <li>crée un objet {@link File} pointant vers un fichier MP3,</li>
     *   <li>encapsule ce fichier dans un {@link FichierMp3},</li>
     *   <li>tente d’extraire les métadonnées via {@link FichierMp3#getMetadonnees()},</li>
     *   <li>affiche les métadonnées ou un message d’erreur.</li>
     * </ol>
     *
     * @param args arguments de la ligne de commande (non utilisés)
     */
    public static void main(String[] args) {

        File f = new File("C:/Users/AdelM/Music/09 Tu sais");
        FichierMp3 m = new FichierMp3(f);

        Metadonnees meta = m.getMetadonnees();
        if (meta != null) {
            System.out.println(meta);
        } else {
            System.out.println("Impossible de lire les métadonnées.");
        }
    }
}
