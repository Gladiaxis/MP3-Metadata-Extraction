package test;

/**
 * Classe de test servant de point d’entrée minimal pour l’application CLI.
 *
 * <h2>Rôle</h2>
 * <p>
 * Cette classe est destinée à des usages de test, d’expérimentation
 * ou de validation de configuration (exécution, packaging, lancement JVM).
 * </p>
 *
 * <p>
 * Contrairement à {@code MainCLI}, cette classe ne contient actuellement
 * aucune logique fonctionnelle : la méthode {@code main} est volontairement
 * laissée vide.
 * </p>
 *
 * <h2>Cas d’utilisation possibles</h2>
 * <ul>
 *   <li>tester la création d’un JAR exécutable sans lancer la vraie CLI</li>
 *   <li>vérifier la configuration du classpath</li>
 *   <li>servir de point d’entrée temporaire lors du développement</li>
 * </ul>
 *
 * <h2>Évolution possible</h2>
 * <p>
 * Cette classe pourra ultérieurement :
 * </p>
 * <ul>
 *   <li>déléguer vers {@code ihm.CLI}</li>
 *   <li>servir de stub pour des tests automatisés</li>
 *   <li>être supprimée une fois la phase de test terminée</li>
 * </ul>
 *
 * @author —
 * @version 1.0
 * @since 2025
 */
public class MainCLIApp {

    /**
     * Point d’entrée minimal de l’application de test.
     *
     * <p>
     * La méthode ne contient volontairement aucune instruction.
     * Elle permet simplement de vérifier que la JVM peut lancer
     * correctement une classe {@code main}.
     * </p>
     *
     * @param args arguments de la ligne de commande (non utilisés)
     */
    public static void main(String[] args) {
        // Méthode volontairement vide (classe de test)
    }
}
